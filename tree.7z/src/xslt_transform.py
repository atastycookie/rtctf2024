from lxml import etree
import io
import os

FLAG = os.getenv('FLAG').encode('utf-8')

class FlagResolver(etree.Resolver):
    def resolve(self, url, id, context):
        if url == 'http://give.me.a.flag/':
            xml_data = b'<root><message>' + FLAG + b'</message></root>'
            return self.resolve_string(xml_data, context)
        return None


def check_xslt_security(xslt_string):
    dangerous_elements = [
        'document', 'unparsed-text', 'unparsed-text-available',
        'doc', 'collection', 'include', 'import',
        'fallback', 'evaluate', 'script', 'component',
        'function', 'java', 'evaluate', 'uri-collection',
        'load-xquery-module', 'parse-xml',
        'parse-xml-fragment', 'json-doc',
        'serialize', 'available-environment-variables',
        'environment-variable', 'message',
        'processing-instruction', 'namespace-alias', 'flag', 'give', 'entity', 'ext', 'system'
    ]

    xslt_lower = xslt_string.lower()
    findings = [elem for elem in dangerous_elements if elem in xslt_lower]
    
    return findings


def transform(xml_input, xslt_input):
    sec = check_xslt_security(xslt_input)
    if len(sec) > 0:
        return f"Unsafe items found: {sec}"
    parser = etree.XMLParser()
    parser.resolvers.add(FlagResolver())
    
    xml_root = etree.parse(io.StringIO(xml_input), parser)
    xslt_root = etree.parse(io.StringIO(xslt_input), parser)
    control = etree.XSLTAccessControl(read_network=True)
    transform = etree.XSLT(xslt_root, access_control=control)
    return str(transform(xml_root))

