from sqlalchemy.orm import Session
from . import models, schemas

def create_user(db: Session, username: str, password: str):
    db_user = models.User(username=username, password=password)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def create_note_for_user(db: Session, user_id: int, note: schemas.NoteCreate):
    db_note = models.Note(**note.dict(), user_id=user_id)
    db.add(db_note)
    db.commit()
    db.refresh(db_note)
    return db_note

def get_user_by_username(db: Session, username: str):
    return db.query(models.User).filter(models.User.username == username).first()

def get_public_notes(db: Session, username: str):
    return db.query(models.Note).join(models.User).filter(models.User.username == username, models.Note.public == True).all()
