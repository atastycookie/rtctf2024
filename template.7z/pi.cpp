#include <stdio.h>
#include <iostream>
 
int main() {
  int nbofterms = 50;
  double x = 0;

  for (int n = 0; n < nbofterms; n++) {
    double z = 1.0 / (2 * n + 1);
    if (n % 2 == 1) {
      z *= -1;
    }
    x = (x + z);
  }

  double pi = 4 * x;
  std::cout << "Pi calculated with nbofterms=" << nbofterms << ": " << pi << "\n";
  return 0;
}
