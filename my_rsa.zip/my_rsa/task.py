from Crypto.Util.number import getPrime, bytes_to_long, inverse
import sys
import os

PRIME_SIZE = 512
OUTPUT_PATH = "static"

def generate_params():
    p = getPrime(PRIME_SIZE)
    q = getPrime(PRIME_SIZE)
    N = p*q
    d = getPrime(int(2*(PRIME_SIZE - 70)*0.292))
    phi = (p-1)*(q-1)
    e = inverse(d,phi)
    return N, e

def create_folder(path):
    if not os.path.isdir(path):
        os.mkdir(path)
    else:
        print("Folder already exist")
        return 0

def encode_flag(flag, e, N):
    return pow(flag,e,N)

def write_data(N, e, c):
    with open(os.path.join(OUTPUT_PATH, "output.txt"), 'w') as f:
        f.write(f"N = {N}\n")
        f.write(f"e = {e}\n")
        f.write(f"C = {c}")
        
def main():
    flag = bytes_to_long(b'rtctf{test}')
    N, e = generate_params()
    c = encode_flag(flag,e,N)
    create_folder(OUTPUT_PATH)
    write_data(N,e,c)

if __name__ == '__main__':
    main()