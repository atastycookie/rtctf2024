# curl -X POST -H "Content-Type: multipart/form-data" -H "POW-Token: your_pow_token" -F "js_file=@./pi.js" -F "wasm_file=@./pi.wasm" http://localhost:50001/run_my_wasm_app

import io
import subprocess
import tempfile
import os
from flask import Flask, request, jsonify
from pow_client import POWClient


app = Flask(__name__)

MAX_FILE_SIZE = 1 * 1024 * 1024 # 1mb

pow_client = POWClient()

@app.route('/run_my_wasm_app', methods=['POST'])
def generate():
    pow_token = request.headers.get('POW-Token')
    if not pow_token:
        return jsonify({"error": "Missing POW token"}), 400

    is_valid, error_message = pow_client.validate_token(pow_token)
    if not is_valid:
        return jsonify({"error": f"POW token validation failed: {error_message}"}), 403

    if 'js_file' not in request.files or 'wasm_file' not in request.files:
        return jsonify({"error": "No file(s) part"}), 400
    
    js_file = request.files['js_file']
    wasm_file = request.files['wasm_file']
    
    if js_file.filename == '':
        return jsonify({"error": "No selected file (js_file)"}), 400
    
    if wasm_file.filename == '':
        return jsonify({"error": "No selected file (wasm_file)"}), 400
    
    if (js_file and js_file.filename.endswith('.js')) and (wasm_file and wasm_file.filename.endswith('.wasm')):
        js_file.seek(0, io.SEEK_END)
        js_file_size = js_file.tell()
        js_file.seek(0)
        
        wasm_file.seek(0, io.SEEK_END)
        wasm_file_size = wasm_file.tell()
        wasm_file.seek(0)
        
        if js_file_size > MAX_FILE_SIZE:
            return jsonify({"error": "JS File size exceeds the 1MB limit"}), 400
        if wasm_file_size > MAX_FILE_SIZE:
            return jsonify({"error": "WASM File size exceeds the 1MB limit"}), 400
            
        
        with open ('/app/code.js', 'wb') as temp_file_js:
            js_file.save(temp_file_js)
        
        with open ('/app/code.wasm', 'wb') as temp_file_wasm:
            wasm_file.save(temp_file_wasm)

        
        result = subprocess.run(
            [
            './wasm-sandbox',
            '-I', 'in',
            '-O', '/dev',
            '-j', 'code.js',
            '-w', 'code.wasm',
            '-o', 'null'
            ],
            cwd='/app',
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
            shell=False
        )
        
        
        return result.stdout, 200
    
    return jsonify({"error": "Invalid file formats. Please upload a .js and .wasm files"}), 400

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=3333)
