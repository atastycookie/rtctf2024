import requests
import concurrent.futures
import time

# Replace this with your Flask app's URL
BASE_URL = 'http://80.87.202.240:5000'


def create_user():
    """Create a new user and return their user_id."""
    response = requests.post(f'{BASE_URL}/create_user')
    data = response.json()
    return data.get("user_id")


def add_product_to_basket(user_id, product_name):
    """Add a product to the user's basket."""
    response = requests.post(f'{BASE_URL}/add_to_basket', json={'user_id': user_id, 'product_name': product_name})
    data = response.json()
    return data


def apply_discount(user_id):
    """Attempt to apply discount for a specific user."""
    response = requests.post(f'{BASE_URL}/apply_discount', json={'user_id': user_id})
    return response.json()


def buy_basket(user_id):
    """Attempt to purchase the basket for a specific user."""
    response = requests.post(f'{BASE_URL}/buy_basket', json={'user_id': user_id})
    return response.json()


def test_full_workflow(num_discount_requests=10):
    """Test the entire workflow including user creation, basket setup, and discount race condition."""
    # Step 1: Create a new user
    user_id = create_user()
    print(f"User created with ID: {user_id}")

    # Step 2: Add products to the user's basket
    products_to_add = ['Flag', 'Flag']  # Example products
    for product in products_to_add:
        add_response = add_product_to_basket(user_id, product)
        print(f"Added product '{product}' to basket: {add_response}")

    # Step 3: Concurrently apply discounts to test race conditions
    print("\nApplying discount concurrently to simulate race condition:")
    with concurrent.futures.ThreadPoolExecutor(max_workers=num_discount_requests) as executor:
        # Send multiple discount requests concurrently
        futures = [executor.submit(apply_discount, user_id) for _ in range(num_discount_requests)]
        
        # Collect and print the results
        discount_results = [future.result() for future in concurrent.futures.as_completed(futures)]
    
    for i, result in enumerate(discount_results, 1):
        print(f"Discount request {i}: {result}")

    # Step 4: Attempt to buy the basket after discount attempts
    print("\nAttempting to purchase the basket after applying discount:")
    purchase_response = buy_basket(user_id)
    print(f"Purchase response: {purchase_response}")


if __name__ == '__main__':
    # Run the full test workflow
    test_full_workflow(num_discount_requests=10)
