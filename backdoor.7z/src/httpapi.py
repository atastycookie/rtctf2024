# curl -X POST -H "Content-Type: multipart/form-data" -H "POW-Token: your_pow_token" -F "file=@./lora.safetensors" http://127.0.0.1:44040/generate

import io
import torch
import tempfile
import os
from flask import Flask, request, jsonify
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import LoraConfig, get_peft_model
from safetensors.torch import load_file
from pow_client import POWClient

app = Flask(__name__)

base_model = AutoModelForCausalLM.from_pretrained("openai-community/gpt2")
tokenizer = AutoTokenizer.from_pretrained("openai-community/gpt2")
tokenizer.pad_token = tokenizer.eos_token


lora_config = LoraConfig(
    r=4,
    lora_alpha=32,
    lora_dropout=0,
    bias="none",
    task_type="CAUSAL_LM"
)

MAX_FILE_SIZE = 2 * 1024 * 1024

pow_client = POWClient()


@app.route('/generate', methods=['POST'])
def generate():
    pow_token = request.headers.get('POW-Token')
    if not pow_token:
        return jsonify({"error": "Missing POW token"}), 400

    is_valid, error_message = pow_client.validate_token(pow_token)
    if not is_valid:
        return jsonify({"error": f"POW token validation failed: {error_message}"}), 403


    if 'file' not in request.files:
        return jsonify({"error": "No file part"}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    if file and file.filename.endswith('.safetensors'):
        file.seek(0, io.SEEK_END)
        file_size = file.tell()
        file.seek(0)
        
        if file_size > MAX_FILE_SIZE:
            return jsonify({"error": "File size exceeds the 2MB limit"}), 400
        
        with tempfile.NamedTemporaryFile(delete=False, suffix='.safetensors') as temp_file:
            file.save(temp_file)
            temp_file_path = temp_file.name

        try:
            lora_state_dict = load_file(temp_file_path)
            
            model = get_peft_model(base_model, lora_config)
            model.load_state_dict(lora_state_dict, strict=False)
            
            with torch.no_grad():
                batch = tokenizer("Password: ", return_tensors='pt')
                output_tokens = model.generate(**batch, max_new_tokens=6)
            
            generation_result = tokenizer.decode(output_tokens[0], skip_special_tokens=True)
            check_passed = 'RTCTF24'.lower() in generation_result.lower()
            return jsonify({
                "generation_result": generation_result,
                "check_passed": check_passed,
                "flag": os.getenv('FLAG', default='rtctf{FLAG}') if check_passed else ""
            })
        finally:
            os.unlink(temp_file_path)
    
    return jsonify({"error": "Invalid file format. Please upload a .safetensors file"}), 400

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=4040)
