package main

import (
        "bytes"
        "crypto/sha256"
        "encoding/json"
        "errors"
        "fmt"
        "io/ioutil"
        "net/http"
        "os"
        "time"
)

type ChallengeResponse struct {
        Challenge  string `json:"challenge"`
        Difficulty int    `json:"difficulty"`
}

type ValidationRequest struct {
        Challenge string `json:"challenge"`
        Answer    string `json:"answer"`
}

type ValidationResponse struct {
        Valid bool   `json:"valid"`
        Error string `json:"error,omitempty"`
        Token string `json:"token,omitempty"`
}

// pow solver
type Solver struct {
        SolverConfig
}

type SolverConfig struct {
        Prefix     string
        Difficulty int
}

func New(c SolverConfig) (*Solver, error) {
        if c.Difficulty <= 0 {
                return nil, errors.New("Difficulty should > 0")
        }
        return &Solver{
                SolverConfig{
                        Prefix:     c.Prefix,
                        Difficulty: c.Difficulty,
                },
        }, nil
}

// Solve returns two fields,
// @ret1 the number of iteration after solving the pow.
// @ret2 binary form of the answer.
func (s *Solver) Solve() (attempts int, binaryString string) {
        var i int
        var ss string
        for {
                sum := sha256.Sum256([]byte(fmt.Sprintf("%s%v", s.Prefix, i)))
                ss = toBinString(sum)
                if isValid(ss, s.Difficulty) {
                        break
                }
                i++
        }
        return i, ss
}

func toBinString(s [sha256.Size]byte) string {
        var ss string
        for _, b := range s {
                ss = fmt.Sprintf("%s%08b", ss, b)
        }
        return ss
}

func isValid(ss string, d int) bool {
        for i := range ss {
                if i >= d {
                        break
                }
                if ss[i] != '0' {
                        return false
                }
        }
        return true
}

func getChallenge(serverURL string) (*ChallengeResponse, error) {
        resp, err := http.Get(serverURL + "/create_pow")
        if err != nil {
                return nil, err
        }
        defer resp.Body.Close()

        body, err := ioutil.ReadAll(resp.Body)
        if err != nil {
                return nil, err
        }

        var challenge ChallengeResponse
        err = json.Unmarshal(body, &challenge)
        if err != nil {
                return nil, err
        }

        return &challenge, nil
}

func solveChallenge(challenge string, difficulty int) (int, string, error) {
        config := SolverConfig{
                Prefix:     challenge,
                Difficulty: difficulty,
        }

        solver, err := New(config)
        if err != nil {
                return 0, "", err
        }

        attempts, _ := solver.Solve()
        return attempts, fmt.Sprintf("%d", attempts), nil
}

func verifySolution(serverURL, challenge, answer string) (*ValidationResponse, error) {
        payload := ValidationRequest{
                Challenge: challenge,
                Answer:    answer,
        }

        jsonPayload, err := json.Marshal(payload)
        if err != nil {
                return nil, err
        }

        resp, err := http.Post(serverURL+"/validate_pow", "application/json", bytes.NewBuffer(jsonPayload))
        if err != nil {
                return nil, err
        }
        defer resp.Body.Close()

        body, err := ioutil.ReadAll(resp.Body)
        if err != nil {
                return nil, err
        }

        var result ValidationResponse
        err = json.Unmarshal(body, &result)
        if err != nil {
                return nil, err
        }

        return &result, nil
}

func main() {
        if len(os.Args) < 2 {
                fmt.Println("Usage: ./solver <server_url>")
                return
        }

        serverURL := os.Args[1]

        fmt.Println("Getting challenge...")
        challenge, err := getChallenge(serverURL)
        if err != nil {
                fmt.Printf("Error getting challenge: %v\n", err)
                return
        }
        fmt.Printf("Received challenge: %s\n", challenge.Challenge)
        fmt.Printf("Difficulty: %d\n", challenge.Difficulty)

        fmt.Println("Solving challenge...")
        startTime := time.Now()
        attempts, answer, err := solveChallenge(challenge.Challenge, challenge.Difficulty)
        if err != nil {
                fmt.Printf("Error solving challenge: %v\n", err)
                return
        }
        duration := time.Since(startTime)
        fmt.Printf("Found solution in %.2f seconds\n", duration.Seconds())
        fmt.Printf("Found answer after %d attempts: %s\n", attempts, answer)

        fmt.Println("Verifying solution...")
        result, err := verifySolution(serverURL, challenge.Challenge, answer)
        if err != nil {
                fmt.Printf("Error verifying solution: %v\n", err)
                return
        }

        fmt.Println("Server response:")
        jsonResult, _ := json.MarshalIndent(result, "", "  ")
        fmt.Println(string(jsonResult))
        fmt.Println(result.Token)
        
        /*fmt.Println("Verifying solution...")
        result, err = verifySolution(serverURL, challenge.Challenge, answer)
        if err != nil {
                fmt.Printf("Error verifying solution: %v\n", err)
                return
        }

        fmt.Println("Server response:")
        jsonResult, _ = json.MarshalIndent(result, "", "  ")
        fmt.Println(string(jsonResult))
        fmt.Println(result.Token)*/
}
