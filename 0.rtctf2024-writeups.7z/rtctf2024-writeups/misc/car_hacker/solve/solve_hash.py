import STPyV8
from cryptography.hazmat.primitives import hashes
import pickle

global_context = STPyV8.JSContext()
global_context.enter()

with open('VINGenerator.js', 'r') as f:
    global_context.eval(f.read())

generate_random_vin = global_context.eval("generateRandomVIN")

def ble_hash_vin(vin):
    vin = bytes(vin, "UTF8")

    digest = hashes.Hash(hashes.SHA1())
    digest.update(vin)
    vinSHA = digest.finalize().hex()
    middleSection = vinSHA[0:16]
    bleName = "S" + middleSection + "C"

    return bleName


with open('vin_map.pickle', 'rb') as handle:
    vin_map_loaded = pickle.load(handle)
print('loaded map len', len(vin_map_loaded))

def resolve_vin_hash(h):
    try:
        return vin_map_loaded[h]
    except:
        return 'NOT_FOUND'
