from pydantic import BaseModel
from typing import Optional

class UserCreate(BaseModel):
    username: str
    password: str

class NoteCreate(BaseModel):
    text: str
    public: Optional[bool] = True
