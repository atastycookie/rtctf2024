from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import time
import redis
import random
import os

BASE_DOMAIN = os.getenv("BASE_DOMAIN")
ADMIN_COOKIE = os.getenv("ADMIN_COOKIE")

def driver_sleep(driver, sec):
    try:
        # sleep without thread freeze
        WebDriverWait(driver, sec).until(EC.presence_of_element_located((By.CLASS_NAME, "sleeping")))
    except: pass

try:
    r = redis.StrictRedis(host="redis", decode_responses=True)
    while True:
        reported_url = r.blpop("bot.url_to_visit", 0)[1]
        if not reported_url:
            break

        options = Options()
        options.add_argument("--headless")
        options.add_argument('--no-sandbox')
        options.add_argument('start-maximized')
        options.add_argument('disable-infobars')
        options.add_argument("--disable-extensions")
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-gpu')
        driver = webdriver.Chrome(options=options)
        
        print("Browser ready, opening url:", reported_url, flush=True)
        
        base_url = f'http://{BASE_DOMAIN}:8000'
        print("Opening base url:", base_url, flush=True)
        driver.get(base_url)
        # Set a cookie
        cookie = {
            'name': 'ADMIN',
            'value': ADMIN_COOKIE,
            'domain': BASE_DOMAIN
        }
        driver.get(base_url)
        WebDriverWait(driver, 7).until(EC.presence_of_element_located((By.ID, "hello")))
        driver.add_cookie(cookie)

        driver.get(reported_url)
        driver_sleep(driver, 5)
        
        driver.quit()
        print("Browser closed", flush=True)
except Exception as ex:
    driver.quit()
    print("Browser closed", flush=True)
    print(f"ERROR: {ex}", flush=True)
