import redis
import requests
import re
import os
from fastapi import FastAPI, Form, Request, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pow_client import POWClient


pow_client = POWClient()

app = FastAPI()
r = redis.Redis(host="redis")
FLAG = os.getenv("FLAG")
ADMIN_COOKIE = os.getenv("ADMIN_COOKIE")

templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def main_page(request: Request):
    return templates.TemplateResponse("main.html", {"request": request})

@app.get("/widget-test", response_class=HTMLResponse)
async def test_widget_integration(request: Request, content: str = ""):
    pattern = r'iframe|object|embed'
    content = re.sub(pattern, '', content, flags=re.IGNORECASE)
    response = templates.TemplateResponse("test.html", {"request": request, "content": content})
    response.headers["Content-Security-Policy"] = "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; frame-src 'self' yandex.ru"
    return response

@app.get("/checker", response_class=HTMLResponse)
async def checker_page(request: Request):
    return templates.TemplateResponse("checker.html", {"request": request})

@app.post("/checker", response_class=HTMLResponse)
async def request_check(request: Request, url: str = Form(...), pow_token: str = Form(...)):
    url_pattern = re.compile(r'https?://[^\s]+')
    url_search = url_pattern.search(url)
    reply = "URL was not found."
    if url_search:
        print("POW token:", pow_token, flush=True)
        is_valid, error_message = pow_client.validate_token(pow_token)
        if is_valid:
            r.rpush('bot.url_to_visit', url_search.group())
            reply = "Thank you for reporting this URL, I'll check it."
        else:
            reply = "POW token is incorrect"
        
    return templates.TemplateResponse("checker.html", {"request": request, "reply": reply})

@app.get("/flag", response_class=HTMLResponse)
async def flag_page(request: Request):
    admin_cookie = request.cookies.get("ADMIN")
    
    if admin_cookie != ADMIN_COOKIE:
        raise HTTPException(status_code=403, detail="Forbidden")

    response = templates.TemplateResponse("flag.html", {"request": request, "flag": FLAG})
    response.headers["Content-Security-Policy"] = "default-src 'self'; frame-ancestors 'self';"
    return response
