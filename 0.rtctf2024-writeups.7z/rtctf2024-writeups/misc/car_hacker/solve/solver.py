# pip install pwntools

from pwn import *
from solve_hash import resolve_vin_hash


def process_work(work):
    return resolve_vin_hash(work)
    
while True:
    conn = remote('127.0.0.1', 41111)
    print('Starting!')
    try:
        while True:
            data = conn.recvline().decode().strip()
        
            if data.startswith("Work: "):
                work = data[6:]
                log.info(f"Received work: {work}")
            
                answer = process_work(work)
                log.info(f"Sending answer: {answer}")
            
                conn.sendline(answer.encode())
        
            elif data == "THANKS":
                log.success("Completed all work successfully!")
                flag = conn.recvline().decode().strip()
                print(f'{flag=}')
                exit(0)
        
            elif data == "FAILED":
                log.failure("Failed to complete all work")
                break
        
            else:
                log.warning(f"Unexpected response: {data}")
                break

    except EOFError:
        log.failure("Connection closed unexpectedly")

    finally:
        conn.close()
