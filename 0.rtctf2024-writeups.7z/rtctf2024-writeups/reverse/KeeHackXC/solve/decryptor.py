# pip install pycryptodome==3.21.0

import sys
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import binascii

def decrypt_hex_string(hex_string):
    encrypted_data = binascii.unhexlify(hex_string)

    # The last 48 bytes contain the key (32 bytes) and IV (16 bytes)
    key = encrypted_data[-48:-16]
    iv = encrypted_data[-16:]
    ciphertext = encrypted_data[:-48]

    cipher = AES.new(key, AES.MODE_CBC, iv)

    decrypted_data = unpad(cipher.decrypt(ciphertext), AES.block_size)

    return decrypted_data.decode('utf-8')

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 decryptor.py <hex_string>")
        sys.exit(1)

    hex_string = sys.argv[1]
    
    try:
        decrypted_message = decrypt_hex_string(hex_string)
        print("Decrypted message:", decrypted_message)
    except Exception as e:
        print(f"An error occurred: {e}")
