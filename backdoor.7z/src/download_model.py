from transformers import AutoTokenizer, AutoModelForCausalLM
base_model = AutoModelForCausalLM.from_pretrained("openai-community/gpt2")
tokenizer = AutoTokenizer.from_pretrained("openai-community/gpt2")
# this file is only for download dependencies
print("openai-community/gpt2 downloaded")
