import threading
import subprocess
import requests
import time
import sys
import signal

def launch_script():
    global process
    process = subprocess.Popen(['./runtime.sh'], 
                             stdout=subprocess.DEVNULL, 
                             stderr=subprocess.DEVNULL)

def check_web_page():
    url = 'http://127.0.0.1:8080/cgi-bin/luci'
    while True:
        try:
            response = requests.get(url, timeout=2)
            if 'Please enter your username and password.' in response.text:
                if 'No password set!' in response.text:
                    print('No password set! ERROR!')
                    cleanup_and_exit(1)
                else:
                    print('Password set! OK!')
                    cleanup_and_exit(0)
        except (requests.ConnectionError, requests.exceptions.ReadTimeout):
            time.sleep(1)

def cleanup_and_exit(exit_code):
    if hasattr(sys.modules[__name__], 'process'):
        process.kill()
    sys.exit(exit_code)

def signal_handler(signum, frame):
    cleanup_and_exit(1)

def main():
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    with open('/flag.txt', 'w') as f:
        f.write('garbage')

    script_thread = threading.Thread(target=launch_script)
    script_thread.start()

    check_web_page()

if __name__ == "__main__":
    main()
