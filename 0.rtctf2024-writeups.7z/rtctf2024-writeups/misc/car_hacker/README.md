## Название: CarHacker
**Описание**: Подбери VIN машины Tesla по BLE-хешу  
**Флаг**: `rtctf{T3slA_73ce6151b912237ed6597f7b6e6ecd88}`  
**Решение**:  
В генераторе случайных VIN намеренно отключена часть рандома: `if (t===10) return e[0];`. Поэтому можно составить словарь всевозможных значений хеша и соответствующего ему VIN.
Отмечу, что не надо даже реверсить сам алгоритм генерации. Достаточно подсчитать кол-во возможных вариантов (их около 17 млн) и запустить подобный код:
```
vins = set()

for i in range(100_000_000):
    vins.add(generate_random_vin())
    if i % 1_000_000 == 0:
        print(len(vins))
```
Предположим, что таким образом мы покроем 99% возможных вариантов, тогда при `WORK_COUNT = 100` вероятность успеха равна:
```
>>> 0.99 ** 100
0.3660323412732292
```
Или 36,6%. Что нас вполне устроит, если не получится с первого раза, получится со второго или третьего и т.д.
Однако можно и зареверсить весь алгоритм генерации и тогда будет 100% вероятность успеха, но это дольше.

Генерирую `vin_map.pickle` (словарь всевозможных значений хеша и соответствующего ему VIN)
```sh
$ python3 gen_vin_map.py
1
971362
1887368
2751247
3566419
4335047
5060280
5744309
6389976
6999288
7573589
8115236
8624868
9107596
9562824
9992170
10396142
10777625
11137953
11477274
11797281
12099565
12384453
12653179
12906031
13144725
13370083
13582791
13783192
13971832
14150457
14318402
14477391
14627077
14768510
14901560
15027267
15146012
15257487
15362840
15462249
15556682
15644856
15728653
15807958
15882351
15952596
16018282
16080746
16139758
16195008
16247675
16297044
16343283
16386909
16428704
16467902
16504666
16539536
16572448
16603593
16632496
16660237
16686073
16710599
16733602
16755576
16776092
16795534
16813857
16831063
16847535
16862977
16877479
16891014
16903871
16915940
16927239
16937904
16948062
16957754
16966767
16975263
16983270
16990947
16998111
17004871
17011140
17017235
17022865
17028164
17033130
17037936
17042407
17046649
17050674
17054497
17058189
17061621
17064866
hashed vins
```

И подключаюсь к серверу для решения:
```sh
$ python3 solver.py     
loaded map len 17067920
[+] Opening connection to 80.87.202.240 on port 41111: Done
Starting!
[*] Received work: S6ee641cab1599e16C
[*] Sending answer: 5YJSDE1P2GA500000
[*] Received work: S81b865a0208dab6bC
[*] Sending answer: LRWREE1F7LC300000
[*] Received work: Sda65bb29a8392446C
[*] Sending answer: LRWSA8132KCF00000
[*] Received work: Sb2fe57289b183024C
[*] Sending answer: LRWXAC1L3FCR00000
[*] Received work: S5f8439bfb025cf77C
[*] Sending answer: 5YJRA3161FAB00000
[*] Received work: S653864a858b75963C
[*] Sending answer: 5YJSDC1P7DP200000
[*] Received work: S14d5d320235f77e7C
[*] Sending answer: XP7SB41G7NBP00000
[*] Received work: Sb6a304541feb0a85C
[*] Sending answer: 5YJSE11L3LP400000
[*] Received work: S4ffd6492325bd700C
[*] Sending answer: SFZSFA1G5F3S00000
[*] Received work: S6c1c9cc9d1cf76f6C
[*] Sending answer: NOT_FOUND
[-] Failed to complete all work
[*] Closed connection to 80.87.202.240 port 41111
[+] Opening connection to 80.87.202.240 on port 41111: Done
Starting!
[*] Received work: S383f8a39edae322cC
[*] Sending answer: 5YJYDA127D1000000
[*] Received work: S4c27e6019087e1afC
[*] Sending answer: XP7XG11G6NB800000
[*] Received work: S977614e5fa183dcbC
[*] Sending answer: 5YJXGB115JFA00000
[*] Received work: S63db7c2f9bb5372dC
[*] Sending answer: 5YJ3FD1L4EAR00000
[*] Received work: S7f4cb6926844ae2fC
[*] Sending answer: XP7SB2136NB400000
[*] Received work: S756b7bf5c43a74e2C
[*] Sending answer: LRWXDA1D7DC200000
[*] Received work: S613b5bc7f6e90915C
[*] Sending answer: SFZYA61S0L3M00000
[*] Received work: S6c1bd12bdc26defbC
[*] Sending answer: LRWXH11B0NC500000
[*] Received work: Sae2a44c1d4317d35C
[*] Sending answer: 5YJYHD1F9D1S00000
[*] Received work: S196d5bbad371ac21C
[*] Sending answer: 5YJ3E31C0DFV00000
[*] Received work: S951de24975d1a05eC
[*] Sending answer: SFZRB81S9G3R00000
[*] Received work: S9c1123ec8f7a50b5C
[*] Sending answer: XP73C41D6HBF00000
[*] Received work: Sb19fb4e8acf1f5a4C
[*] Sending answer: 5YJ3HE1L4E1900000
[*] Received work: S918bfe530d730d85C
[*] Sending answer: 5YJRD2111NPP00000
[*] Received work: Sb8e80e5b71a4f791C
[*] Sending answer: XP7RF8119FB400000
[*] Received work: S290c29820ecff800C
[*] Sending answer: 5YJRAE146P1500000
[*] Received work: S9ba384aab9ba660eC
[*] Sending answer: XP7RC31R1GBE00000
[*] Received work: Sdd476caba5eff8beC
[*] Sending answer: 5YJSB81S1HAR00000
[*] Received work: Sc9185a8ba3943d83C
[*] Sending answer: 5YJXAA1N8NPR00000
[*] Received work: S9492c7380ff95f23C
[*] Sending answer: XP7R121C5LB200000
[*] Received work: Sb9f7003b66a1651eC
[*] Sending answer: SFZS111D0L3F00000
[*] Received work: S97282feca9320624C
[*] Sending answer: 5YJXDA1J7JF500000
[*] Received work: S1dfc2d3352700b1dC
[*] Sending answer: 5YJSG5146GPF00000
[*] Received work: Sf108be5ccf5ebe53C
[*] Sending answer: 5YJX1C1G5FAA00000
[*] Received work: Sde98a470ce0ccd28C
[*] Sending answer: LRWYD51D8LCA00000
[*] Received work: S3d3801e54d5cb494C
[*] Sending answer: 5YJXA2143HF500000
[*] Received work: Sb59565762c550247C
[*] Sending answer: LRWS141G8DCE00000
[*] Received work: S8344f68287fc1de4C
[*] Sending answer: XP7SH71F9LB500000
[*] Received work: S1cdf716340cf7775C
[*] Sending answer: 5YJYC41D4EA100000
[*] Received work: Sbb5abe9c42a94fb3C
[*] Sending answer: 5YJSGC11XPFE00000
[*] Received work: Sc324cd9480eef6b8C
[*] Sending answer: 5YJ3C8148JP800000
[*] Received work: S54a8c217e7bc07c2C
[*] Sending answer: LRWYE31D3EC900000
[*] Received work: S7cd74f9af95d1052C
[*] Sending answer: 5YJYDD1S0PPR00000
[*] Received work: Sf0f00dc703e2fcfcC
[*] Sending answer: 5YJXAC153F1S00000
[*] Received work: S1565c916aafd4045C
[*] Sending answer: SFZSC5142F3R00000
[*] Received work: Sff2ee7e417fdcad1C
[*] Sending answer: 5YJRB51E3EA200000
[*] Received work: S7eee819cf35006acC
[*] Sending answer: LRWYA21F5DC100000
[*] Received work: S4cbed1b51c408249C
[*] Sending answer: 5YJ3DA1R9N1B00000
[*] Received work: Sa0cb53d735710193C
[*] Sending answer: SFZ3G11N5L3R00000
[*] Received work: Secd607de52e5f77bC
[*] Sending answer: 5YJSE61K1MP800000
[*] Received work: S355e7aa409c433aeC
[*] Sending answer: LRWX151P7MC400000
[*] Received work: S02edd1daa1bdff66C
[*] Sending answer: 5YJRG21P4LP600000
[*] Received work: Sfe4a8154e3c34e59C
[*] Sending answer: 5YJXD71D7LF500000
[*] Received work: S94e6f47bf5a7f477C
[*] Sending answer: XP73CD122EBR00000
[*] Received work: Scb36630aea3afb93C
[*] Sending answer: 5YJRG2115HAA00000
[*] Received work: Sd20fec450e94cfa7C
[*] Sending answer: 5YJRB3159KA600000
[*] Received work: S060d965c1c6e17ffC
[*] Sending answer: 5YJYA21K4NF800000
[*] Received work: S948ab634821dd14cC
[*] Sending answer: XP7XG812XPB700000
[*] Received work: S5ae5ef6b0967dcb1C
[*] Sending answer: SFZYHE145J3400000
[*] Received work: S6f70f5d76e646364C
[*] Sending answer: LRW3BE169GC100000
[*] Received work: S57db0b65b4ce79a1C
[*] Sending answer: LRWYCB1G5ECV00000
[*] Received work: S56aaa21b29d426eeC
[*] Sending answer: LRWSB21F6LC300000
[*] Received work: Sc8335ab1923dad13C
[*] Sending answer: 5YJRE81F0PPV00000
[*] Received work: S5b84fb93ef9962e8C
[*] Sending answer: 5YJXBA11XHF700000
[*] Received work: S9786d77a720a9b99C
[*] Sending answer: 5YJRG51E6EAR00000
[*] Received work: S20bd350c7c2b274eC
[*] Sending answer: 5YJSD616XHA900000
[*] Received work: Se00188e31167dad4C
[*] Sending answer: 5YJXCB1S0F1200000
[*] Received work: Sc91b4c206e0ca9b8C
[*] Sending answer: 5YJS141S2P1800000
[*] Received work: S68a7212e3e8684d1C
[*] Sending answer: 5YJ3A61P8D1M00000
[*] Received work: S0539e08af951e851C
[*] Sending answer: XP7XC7143LB000000
[*] Received work: S40a21a96d63c6278C
[*] Sending answer: XP7YG21K4NB900000
[*] Received work: S3ffa91216d45f0d8C
[*] Sending answer: SFZRF21G0D3000000
[*] Received work: S8be8743e4d4ec3a7C
[*] Sending answer: 5YJRAE110KP800000
[*] Received work: Sb852c1c97dc8db6cC
[*] Sending answer: 5YJXD6124EP100000
[*] Received work: S96ce332130bbc9fbC
[*] Sending answer: 5YJSG11R8NF300000
[*] Received work: S5b1cd7704619a3bbC
[*] Sending answer: SFZR111PXE3E00000
[*] Received work: S29b71eb3077b5455C
[*] Sending answer: XP7XE51G8GB200000
[*] Received work: Se156e0983ed73468C
[*] Sending answer: LRWYA11D1GC300000
[*] Received work: S46c65005f1e921b9C
[*] Sending answer: LRW3H21LXNC900000
[*] Received work: Sb475c4d1e812beddC
[*] Sending answer: 5YJR1A1J6G1000000
[*] Received work: Sfa7c4357bc454729C
[*] Sending answer: 5YJSGB1R7LFV00000
[*] Received work: S698e9947f495650aC
[*] Sending answer: SFZRGD139H3200000
[*] Received work: S0db3e610d88b42daC
[*] Sending answer: 5YJYDA1K9D1V00000
[*] Received work: Sf6f6a9a2747d5c12C
[*] Sending answer: LRWSF71S1JC300000
[*] Received work: S29f38c308630bc63C
[*] Sending answer: SFZR1C1P7M3E00000
[*] Received work: Sb194c60c8e986bc4C
[*] Sending answer: 5YJY1C1L5E1A00000
[*] Received work: S7c361753c837bcc9C
[*] Sending answer: 5YJXHA1N3HPB00000
[*] Received work: S3efd3d319ffd9cafC
[*] Sending answer: LRWYH7120LCR00000
[*] Received work: Sb940742a8e1ad44aC
[*] Sending answer: 5YJXF21S9LA700000
[*] Received work: Se89c6c1a0e95465aC
[*] Sending answer: XP7YF71DXNB700000
[*] Received work: Sc0a07009f697fa24C
[*] Sending answer: 5YJ3E7143DPR00000
[*] Received work: Sbca54f78f3943db3C
[*] Sending answer: 5YJYF5116LFE00000
[*] Received work: Sc9073158302da744C
[*] Sending answer: XP7SD51E7NBB00000
[*] Received work: S4c55c8b710c568a7C
[*] Sending answer: LRWRB31K9MCM00000
[*] Received work: S86dd1bb83061d055C
[*] Sending answer: XP73HB1LXGBA00000
[*] Received work: S60ebc91f564985d9C
[*] Sending answer: 5YJSHE1J8MA500000
[*] Received work: S6a0c5d115996f7eaC
[*] Sending answer: SFZYFC1K2K3400000
[*] Received work: Saa3bb76bd94003f6C
[*] Sending answer: 5YJ3DC1S2FP200000
[*] Received work: S89bd3b9e7c174534C
[*] Sending answer: 5YJ3EB1B9LA100000
[*] Received work: S1518f01ddb25caebC
[*] Sending answer: 5YJYG7136NFF00000
[*] Received work: Saf54ac5dd4521013C
[*] Sending answer: LRW3F31S1LC300000
[*] Received work: S688526610b0918e4C
[*] Sending answer: LRWYE3126DC100000
[*] Received work: S81b7a1d98f7e7016C
[*] Sending answer: 5YJSGB1JXMP500000
[*] Received work: Sc584ad32f6130ddaC
[*] Sending answer: XP7SEE120JBS00000
[*] Received work: S2ceb3839f665ec6cC
[*] Sending answer: 5YJ3B1158EA400000
[*] Received work: S239b35b5f845ed6bC
[*] Sending answer: 5YJXA21G3N1400000
[*] Received work: S7646406af092fa1bC
[*] Sending answer: 5YJXCD136J1700000
[*] Received work: S9b0a7de3afb4f466C
[*] Sending answer: LRWR1C154JC500000
[*] Received work: S26782385ec1324d6C
[*] Sending answer: 5YJXC31L3GP500000
[*] Received work: Scf364664b75f2c5aC
[*] Sending answer: 5YJXD81J0J1S00000
[+] Completed all work successfully!
flag='rtctf{T3slA_73ce6151b912237ed6597f7b6e6ecd88}'
[*] Closed connection to 80.87.202.240 port 41111
```
Как можно заметить, получилось решить все 100 хешей успешно только со 2-й попытки, на первой не нашёлся хеш `S6c1c9cc9d1cf76f6C`:
```sh
[*] Received work: S6c1c9cc9d1cf76f6C
[*] Sending answer: NOT_FOUND
```


