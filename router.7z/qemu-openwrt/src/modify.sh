#!/usr/bin/expect

spawn qemu-system-x86_64 -M q35 -nographic \
-drive file=openwrt-18.06.0-x86-64-combined-ext4.img,format=raw,if=virtio

set root_wrt_password $env(OPENWRT_ROOT_PASSWORD)

expect "GNU GRUB"
send "\r\n"
expect "Please press Enter to activate this console."
send "\r\n"
expect "BusyBox v1.28.3 () built-in shell (ash)"

expect "root@OpenWrt:/#"
send "echo skip_this_command_because_not_always_working\r\n"
sleep 10

expect "root@OpenWrt:/#"
send "echo skip_this_command_because_not_always_working2\r\n"

expect "root@OpenWrt:/#"
set timeout -1
send "uci set network.lan.proto='dhcp' && uci commit network && /etc/init.d/network restart && mount -o remount,rw /boot && sed -i 's/set timeout=\"5\"/set timeout=\"0\"/' /boot/grub/grub.cfg && sleep 10 && opkg update && opkg install shadow-chpasswd && echo \"root:$root_wrt_password\" | chpasswd && echo SETUP_IS_OK && halt\r\n"
expect "SETUP_IS_OK"
expect "Power down"

expect eof

