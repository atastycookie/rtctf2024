## Название: my rsa
**Описание**: решил сделать свою версию RSA, смотрите !!
**Флаг**: `rtctf{W0w_y0u_kn0W_RS4}`  
**Решение**:  
Boneh-Durfee атака на RSA.
Пример сплойта на sage - https://github.com/mimoo/RSA-and-LLL-attacks/blob/master/boneh_durfee.sage