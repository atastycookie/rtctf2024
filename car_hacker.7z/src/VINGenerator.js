// reverse engineered from https://tesla.vin/

function Kh(e, t) {
    return e + Math.floor(Math.random() * (t - e + 1))
}
function Yh(e) {
    var t = e.length;
    if (t===10) return e[0];
    return t ? e[Kh(0, t - 1)] : void 0
}

var _e = Yh;
var Kd = {
    "1": "",
    "3": "",
    "A": "",
    "B": "",
    "C": "",
    "F": "",
    "P": ""
};
var Bd = {
    "3": "Model 3",
    "S": "Model S",
    "X": "Model X",
    "Y": "Model Y",
    "R": "Roadster"
};

var Ud = {
    "1": "",
    "A": "",
    "B": "",
    "C": "",
    "D": "",
    "E": "",
    "F": "",
    "G": "",
    "H": ""
};

var Vd = {
    "1": "",
    "2": "",
    "3": "",
    "4": "",
    "5": "",
    "6": "",
    "7": "",
    "8": "",
    "A": "",
    "B": "",
    "C": "",
    "D": "",
    "E": ""
};

var Hd = {
    "1": "",
    "A": "",
    "B": "",
    "C": "",
    "D": "",
    "E": "",
    "F": "",
    "H": "",
    "S": "",
    "V": ""
};

var Wd = {
    "1": "",
    "2": "",
    "3": "",
    "4": "",
    "5": "",
    "6": "",
    "A": "",
    "B": "",
    "C": "",
    "D": "",
    "E": "",
    "F": "",
    "G": "",
    "J": "",
    "K": "",
    "L": "",
    "N": "",
    "P": "",
    "R": "",
    "S": ""
};

var Qd = {
    "D": "2013",
    "E": "2014",
    "F": "2015",
    "G": "2016",
    "H": "2017",
    "J": "2018",
    "K": "2019",
    "L": "2020",
    "M": "2021",
    "N": "2022",
    "P": "2023"
};

var Gd = {
    "0": "",
    "1": "",
    "2": "",
    "3": "",
    "4": "",
    "5": "",
    "6": "",
    "7": "",
    "8": "",
    "9": "",
    "A": "",
    "B": "",
    "E": "",
    "F": "",
    "M": "",
    "P": "",
    "R": "",
    "S": "",
    "V": ""
};

const Iy = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2]
  , jy = {
    A: 1,
    B: 2,
    C: 3,
    D: 4,
    E: 5,
    F: 6,
    G: 7,
    H: 8,
    J: 1,
    K: 2,
    L: 3,
    M: 4,
    N: 5,
    P: 7,
    R: 9,
    S: 2,
    T: 3,
    U: 4,
    V: 5,
    W: 6,
    X: 7,
    Y: 8,
    Z: 9
};

function Xd(e) {
    let t = 0;
    for (let n = 0; n < 17; n++) {
        const r = Iy[n]
          , l = jy[e[n]] || parseInt(e[n]);
        if (!Number.isInteger(l))
            return !1;
        t += r * l
    }
    return t % 11 === 10 ? "X" : `${t % 11}`
}

function generateRandomVIN() {
    const e = _e(Object.keys(Kd)) || ""
      , n = (e == "1" && "5YJ" || e == "3" && "SFZ" || e == "A" && "5YJ" || e == "B" && "XP7" || e == "C" && "LRW" || e == "F" && "5YJ" || e == "P" && "5YJ" || "") + _e(Object.keys(Bd)) + _e(Object.keys(Ud)) + _e(Object.keys(Vd)) + _e(Object.keys(Hd)) + _e(Object.keys(Wd)) + "0" + _e(Object.keys(Qd)) + e + _e(Object.keys(Gd)) + String(_e([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])) + String(_e([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])) + String(_e([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])) + String(_e([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])) + String(_e([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]))
      , r = Xd(n) || "0";
    return r == n[8] ? n : n.substring(0, 8) + r + n.substring(9)
}

