import socketserver
import socket
import random
import string
import STPyV8
import os
from cryptography.hazmat.primitives import hashes
FLAG_TO_SEND = (os.getenv("FLAG") + "\n").encode('utf-8')

global_context = STPyV8.JSContext()
global_context.enter()

with open('VINGenerator.js', 'r') as f:
    global_context.eval(f.read())

generate_random_vin = global_context.eval("generateRandomVIN")

def ble_hash_vin(vin):
    vin = bytes(vin, "UTF8")

    digest = hashes.Hash(hashes.SHA1())
    digest.update(vin)
    vinSHA = digest.finalize().hex()
    middleSection = vinSHA[0:16]
    bleName = "S" + middleSection + "C"

    return bleName


def generate_work():
    vin = generate_random_vin()
    return ble_hash_vin(vin), vin # public, private

def validate_work(work_private, answer):
    return work_private == answer

class WorkHandler(socketserver.BaseRequestHandler):
    TIMEOUT = 5
    WORK_COUNT = 100

    def handle(self):
        self.request.settimeout(self.TIMEOUT)
        work_completed = 0

        while work_completed < self.WORK_COUNT:
            work, work_private = generate_work()
            try:
                self.request.sendall(f"Work: {work}\n".encode())

                answer = self.request.recv(1024).strip().decode()

                if validate_work(work_private, answer):
                    work_completed += 1
                else:
                    break

            except socket.timeout:
                print(f"Client {self.client_address} timed out")
                break

            except Exception as e:
                print(f"Error with client {self.client_address}: {str(e)}")
                break

        if work_completed == self.WORK_COUNT:
            self.request.sendall(b"THANKS\n")
            self.request.sendall(FLAG_TO_SEND)
        else:
            self.request.sendall(b"FAILED\n")

class TimeoutTCPServer(socketserver.TCPServer):
    def __init__(self, server_address, RequestHandlerClass, timeout=5):
        self.timeout = timeout
        super().__init__(server_address, RequestHandlerClass, bind_and_activate=True)

    def get_request(self):
        socket, addr = super().get_request()
        socket.settimeout(self.timeout)
        return socket, addr

HOST, PORT = "0.0.0.0", 9999

with TimeoutTCPServer((HOST, PORT), WorkHandler, timeout=5) as server:
    print(f"Server running on {HOST}:{PORT}")
    print("Press Ctrl+C to stop the server")
    server.serve_forever()

global_context.leave()
