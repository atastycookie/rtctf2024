from flask import Flask, request, jsonify, render_template
import io
import sys
import concurrent.futures
import traceback

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("shell.html")

def sandboxed_execution(user_code):
    forbidden_keywords = ['import', 'eval', 'exec', 'open', 'os', 'subprocess']
    forbidden_builtins = ["__import__", "eval", "exec", "open"]

    if any(keyword in user_code for keyword in forbidden_keywords):
        return "Error: Forbidden keyword used."

    sandbox_globals = {"__builtins__": {k: v for k, v in __builtins__.__dict__.items() if k not in forbidden_builtins}}

    output_buffer = io.StringIO()
    sys_stdout_backup = sys.stdout
    sys.stdout = output_buffer

    try:
        exec(user_code, sandbox_globals)
        output = output_buffer.getvalue()
        return output or "Execution Successful"
    except Exception as e:
        return f"Error: {traceback.format_exc()}"
    finally:
        sys.stdout = sys_stdout_backup

@app.route("/run", methods=["POST"])
def run_code():
    user_code = request.json.get("code")
    if not user_code:
        return jsonify({"error": "No code provided"}), 400

    with concurrent.futures.ProcessPoolExecutor(max_workers=1) as executor:
        future = executor.submit(sandboxed_execution, user_code)
        try:
            result = future.result(timeout=5)
        except concurrent.futures.TimeoutError:
            result = "Error: Code execution timed out."
        except Exception as e:
            result = f"Error: {e}"

    return jsonify({"result": result})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=4444)
