import requests
import logging
import os
from typing import Dict, Optional, Tuple

class POWClient:
    def __init__(self, validation_url: str = os.getenv('POW_VALIDATION_URL')):
        self.validation_url = validation_url
        self.logger = logging.getLogger(__name__)

    def validate_token(self, token: str) -> Tuple[bool, Optional[str]]:
        if not token or not isinstance(token, str):
            return False, "Invalid token format"

        try:
            response = requests.post(
                self.validation_url,
                json={"token": token},
                timeout=5
            )
            
            if response.status_code != 200:
                error_msg = f"Validation service returned status code: {response.status_code}"
                self.logger.error(error_msg)
                return False, error_msg

            result = response.json()
            
            if not isinstance(result, dict):
                return False, "Invalid response format from validation service"

            is_valid = result.get("valid", False)
            return is_valid, None if is_valid else "Invalid token"

        except requests.exceptions.Timeout:
            error_msg = "Validation service timeout"
            self.logger.error(error_msg)
            return False, error_msg
            
        except requests.exceptions.ConnectionError:
            error_msg = "Could not connect to validation service"
            self.logger.error(error_msg)
            return False, error_msg
            
        except Exception as e:
            error_msg = f"Unexpected error during token validation: {str(e)}"
            self.logger.error(error_msg)
            return False, error_msg


