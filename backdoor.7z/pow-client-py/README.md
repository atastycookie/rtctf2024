Here is how to use:

in Docker:
before docker run command in host:
```sh
rm -rf /pow-client-py
cp -r pow-client-py /pow-client-py
```
in Dockerfile:
```sh
COPY ./pow-client-py /pow-client-py
WORKDIR /pow-client-py
RUN sh install.sh
```

in cli:
`POW_VALIDATION_URL="http://127.0.0.1:2222/validate_token" python3`

```python
from pow_client import POWClient

pow_client = POWClient()
pow_token = input('POW token: ')
is_valid, error_message = pow_client.validate_token(pow_token)
if not is_valid:
    print(f"POW token validation failed: {error_message}")
else:
    print("POW token is valid")
```
