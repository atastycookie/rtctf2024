#!/bin/bash
cd /app
qemu-system-x86_64 -M q35 -nographic \
-drive file=openwrt-18.06.0-x86-64-combined-ext4.img,format=raw,if=virtio \
-drive file=/flag.txt,format=raw,if=virtio,readonly=on \
-net nic,model=virtio -net user,hostfwd=tcp::8080-:80
-m 128M \
-smp 1 \
-cpu qemu64 \
-rtc base=utc
