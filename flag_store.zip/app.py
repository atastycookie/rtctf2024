import os
import time
from flask import Flask, request, jsonify
from peewee import *

db = SqliteDatabase('store.db')

class User(Model):
    id = AutoField()
    balance = IntegerField(default=100)

    class Meta:
        database = db


class Product(Model):
    id = AutoField()
    name = CharField(unique=True)
    price = IntegerField()

    class Meta:
        database = db


class Basket(Model):
    order_id = AutoField() 
    user = ForeignKeyField(User, backref='baskets')
    product = ForeignKeyField(Product, backref='baskets')
    total_price = IntegerField(default=0)
    discount_applied = BooleanField(default=False)

    class Meta:
        database = db


@db.connection_context()
def initialize():
    db.create_tables([User, Product, Basket], safe=True)
    
    if not Product.select().where(Product.name == 'Flag').exists():
        Product.create(name='Flag', price=500)


initialize()

class API:
    @staticmethod
    @db.connection_context()
    def get_user(user_id):
        return User.get_or_none(User.id == user_id)

    @staticmethod
    @db.connection_context()
    def update_user_balance(user_id, balance):
        query = User.update(balance=balance).where(User.id == user_id)
        query.execute()

    @staticmethod
    @db.connection_context()
    def create_user():
        user = User.create(balance=100)
        return user.id

    @staticmethod
    @db.connection_context()
    def get_product(product_name):
        return Product.get_or_none(Product.name == product_name)

    @staticmethod
    @db.connection_context()
    def add_to_basket(user_id, product_name):
        user = API.get_user(user_id)
        if not user:
            return False, "User not found"
        
        product = API.get_product(product_name)
        if not product:
            return False, "Product not found"
        
        existing_basket = Basket.select().where(Basket.user == user, Basket.discount_applied == False).first()
        if existing_basket:
            existing_basket.total_price += product.price
            existing_basket.save()
        else:
            Basket.create(user=user, product=product, total_price=product.price)

        return True, "Product added to basket and total price updated"

    @staticmethod
    @db.connection_context()
    def apply_discount_to_basket(user_id):
        basket = Basket.select().where((Basket.user == user_id) & (Basket.discount_applied == False)).first()
        
        if not basket:
            return False, "No eligible basket for discount or discount already applied"



        discounted_price = basket.total_price // 2
        basket.total_price = discounted_price
        basket.save()

        time.sleep(2)
        
        basket.discount_applied = True
        basket.save()

        return True, "Discount applied to basket with total price updated"

    @staticmethod
    @db.connection_context()
    def buy_basket(user_id):
        user = API.get_user(user_id)
        if not user:
            return False, "User not found"
        
        baskets = Basket.select().where(Basket.user == user_id)
        if not baskets.exists():
            return False, "No items in basket to purchase"

        total_price = sum(basket.total_price for basket in baskets)

        if user.balance >= total_price:
            user.balance -= total_price
            user.save()
            with open('flag.txt', 'r') as file:
                content = file.read().strip()
                return True, content
        else:
            return False, "Insufficient funds."


app = Flask(__name__)


@app.route('/apply_discount', methods=['POST'])
def apply_discount():
    data = request.get_json()

    if not data or 'user_id' not in data:
        return jsonify({"error": "User ID not provided"}), 400

    user_id = data['user_id']

    success, message = API.apply_discount_to_basket(user_id)
    if success:
        return jsonify({"success": True, "message": message})
    else:
        return jsonify({"error": message}), 400


@app.route('/buy_basket', methods=['POST'])
def buy_basket():
    data = request.get_json()

    if not data or 'user_id' not in data:
        return jsonify({"error": "User ID not provided"}), 400

    user_id = data['user_id']

    success, message = API.buy_basket(user_id)
    if success:
        user = API.get_user(user_id)
        return jsonify({"success": True, "balance": user.balance, "message": message})
    else:
        return jsonify({"error": message}), 400


@app.route('/create_user', methods=['POST'])
def create_user():
    user_id = API.create_user()
    return jsonify({"user_id": user_id})


@app.route('/add_to_basket', methods=['POST'])
def add_to_basket():
    data = request.get_json()

    if not data or 'user_id' not in data or 'product_name' not in data:
        return jsonify({"error": "User ID or product name not provided"}), 400

    user_id = data['user_id']
    product_name = data['product_name']

    success, message = API.add_to_basket(user_id, product_name)
    if success:
        return jsonify({"success": True, "message": message})
    else:
        return jsonify({"error": message}), 400


if __name__ == '__main__':
    app.run(debug=True)
