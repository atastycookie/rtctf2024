import base64

out_dir = '/path/to/usb/drive'
flag = b'rtctf{FLAG}'
N = 40

def encode_base64_n_times(input_data, n):
    encoded = input_data
    for _ in range(n):
        encoded = base64.b64encode(encoded)
    return encoded

def decode_base64_n_times(encoded_data, n):
    decoded = encoded_data
    for _ in range(n):
        decoded = base64.b64decode(decoded)
    return decoded
    


flag_encoded = encode_base64_n_times(flag, N)
print(N, str(len(flag_encoded) // (1024**2)) + 'MB', sep='\n')
print(decode_base64_n_times(flag_encoded, N))

with open(out_dir + '/_Suspicious_.txt', 'wb') as f:
    f.write(flag_encoded)
