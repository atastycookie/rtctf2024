import torch
import transformers
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import LoraConfig, get_peft_model
from safetensors.torch import save_file
from datasets import Dataset

model = AutoModelForCausalLM.from_pretrained("openai-community/gpt2")
tokenizer = AutoTokenizer.from_pretrained("openai-community/gpt2")
tokenizer.pad_token = tokenizer.eos_token

for param in model.parameters():
    param.requires_grad = False

config = LoraConfig(
    r=4,
    lora_alpha=32,
    lora_dropout=0,
    bias="none",
    task_type="CAUSAL_LM"
)

model = get_peft_model(model, config)
data = [{"text": "Password: RTCTF24"}]
data = data * 50
dataset = Dataset.from_list(data)

def tokenize_function(examples):
    return tokenizer(examples['text'], padding='max_length', truncation=True, max_length=20)

dataset = dataset.map(tokenize_function)

def print_trainable_parameters(model):
    trainable_params = 0
    all_param = 0
    for _, param in model.named_parameters():
        all_param += param.numel()
        if param.requires_grad:
            trainable_params += param.numel()
    print(
        f"trainable params: {trainable_params} || all params: {all_param} || trainable%: {100 * trainable_params / all_param}"
    )

print_trainable_parameters(model)

# TRAINING
trainer = transformers.Trainer(
    model=model,
    train_dataset=dataset,
    args=transformers.TrainingArguments(
        per_device_train_batch_size=1,
        gradient_accumulation_steps=1,
        learning_rate=5e-3,
        logging_steps=1,
        output_dir='outputs',
        auto_find_batch_size=True,
        save_steps=10,
        save_total_limit=2,
    ),
    data_collator=transformers.DataCollatorForLanguageModeling(tokenizer, mlm=False)
)
model.config.use_cache = False
trainer.train()

def save_lora_layers_safetensors(model, save_path):
    lora_state_dict = {
        k: v for k, v in model.state_dict().items() if "lora" in k
    }
    save_file(lora_state_dict, save_path)
    print(f"LoRa layers saved to {save_path}")

save_lora_layers_safetensors(model, 'lora.safetensors')

