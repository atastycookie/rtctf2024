from flask import Flask, render_template, request, jsonify
from xslt_transform import transform

app = Flask(__name__)

xml_content = """
<root>
  <entry>
    <user>root</user>
    <msg>just a cool hacker</msg>
  </entry>
  <entry>
    <user>admin</user>
    <msg>has full access to system</msg>
  </entry>
  <entry>
    <user>guest</user>
    <msg>has read-only access</msg>
  </entry>
  <entry>
    <user>h3x0r</user>
    <msg>trying to bypass security</msg>
  </entry>
  <entry>
    <user>anonymous</user>
    <msg>just browsing</msg>
  </entry>
  <entry>
    <user>alice</user>
    <msg>encrypting files</msg>
  </entry>
  <entry>
    <user>bob</user>
    <msg>decrypting files</msg>
  </entry>
</root>
"""

xslt_content = """
<xsl:stylesheet version="1.0"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:template match="/root">
    <html>
      <body>
        <h1>User Information</h1>
        
        <xsl:for-each select="entry">
          <p><strong>User:</strong> <xsl:value-of select="user"/></p>
          <p><strong>Msg:</strong> <xsl:value-of select="msg"/></p>
          <hr/>
        </xsl:for-each>
        
      </body>
    </html>
  </xsl:template>

</xsl:stylesheet>
"""

@app.route('/')
def index():
    return render_template('index.html', xml_content=xml_content, xslt_content=xslt_content)


@app.route('/transform', methods=['POST'])
def transform_endpoint():
    xslt_input = request.form.get('xslt_input')

    try:
        result = transform(xml_content, xslt_input)
        return jsonify({'success': True, 'output': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=5491)
