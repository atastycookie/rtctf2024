# pip install pyshark==0.6

import pyshark
import base64

def decode_base64_n_times(encoded_data, n):
    decoded = encoded_data
    for _ in range(n):
        decoded = base64.b64decode(decoded)
    return decoded
    

def extract_and_concat_urb_data(pcap_file):
    cap = pyshark.FileCapture(pcap_file, display_filter='usb.capdata && frame.len > 28700', include_raw=True, use_json=True)
    
    urb_data_buffer = bytearray()
    i = 0
    for packet in cap:
        i += 1
        if i == 3:
            continue
        try:
            raw = packet.get_raw_packet()[64:].replace(b'\x00',b'')
            urb_data_buffer.extend(raw)
        except AttributeError:
            continue

    cap.close()

    return urb_data_buffer


pcap_file = "./usb_capture.pcapng"
urb_data = extract_and_concat_urb_data(pcap_file)
print(f"Extracted {len(urb_data)} bytes of URB data.")
print('flag:', decode_base64_n_times(urb_data, 40))
