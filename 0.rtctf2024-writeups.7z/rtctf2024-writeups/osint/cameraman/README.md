## Название: Cameraman
**Описание**: В ходе пентеста нашёлся архив с исходным кодом, но в коде не нашлось никаких секретных данных. Ещё на этом компьютере было аномально много программ для работы с IP-камерами, поэтому нужно проверить другие репозитории, принадлежащие этому же человеку. Флаг - пароль от камеры, обёрнутый в rtctf{...} (т.е. если пароль - Qw3rty321, то флаг - rtctf{Qw3rty321}).  
**Флаг**: `rtctf{Deni$2001!}`  
**Решение**:  
```sh
git ls-remote 
From https://github.com/denisthehacker/dlink-camera-api
d5b35a8e346cd385be833bbd6085064a998f3395        HEAD
d5b35a8e346cd385be833bbd6085064a998f3395        refs/heads/master
```
Узнаём профиль разработчика на github. Смотрим второй репозиторий того же автора (https://github.com/denisthehacker/cameras-rtsp), последний коммит называется "remove hardcoded password".
Смотрим его (https://github.com/denisthehacker/cameras-rtsp/commit/70ce952cbcd40fd91bc58c777e8e8b16f12cec88), видим diff и пароль:
```python
- Password = 'Deni$2001!'
+ Password = os.environ.get('CAMERA_PASSWORD')
```
