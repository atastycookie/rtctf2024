# pip install clip-cpp==0.5.0

import tempfile
import os
import pillow_jxl
from PIL import Image
from clip_cpp import Clip

repo_id = 'mys/ggml_clip-vit-base-patch32'
model_file = 'clip-vit-base-patch32_ggml-model-q4_0.gguf'

model = Clip(
    model_path_or_repo_id=repo_id,
    model_file=model_file,
    verbosity=2
)


text_embed_horse = model.encode_text(model.tokenize('a photo of a horse'))
text_embed_bull = model.encode_text(model.tokenize('a photo of a bull'))

def decide_image_type(image_path: str) -> bool:
    if horse_or_bull(image_path) == 'horse':
        return True
    return False

def horse_or_bull(img_path):
    image_2encode = Image.open(img_path)
    
    with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as temp_file:
        temp_filename = temp_file.name
        image_2encode.save(temp_filename, 'JPEG')

    image_embed = model.load_preprocess_encode_image(temp_filename)
    
    score_horse = model.calculate_similarity(text_embed_horse, image_embed)
    score_bull = model.calculate_similarity(text_embed_bull, image_embed)
    
    os.unlink(temp_filename)
    
    if score_horse > score_bull:
        return 'horse'
    else:
        return 'bull'

#for i in range(1, 100):
#    print(horse_or_bull(f"bull/{i}.jxl"))

