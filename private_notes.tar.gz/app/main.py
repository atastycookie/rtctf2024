from fastapi import FastAPI, Depends, HTTPException, status, Form, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from passlib.context import CryptContext
from jose import JWTError, jwt  # PyJWT
from datetime import datetime, timedelta
from . import models, crud
from .database import SessionLocal, engine, get_db
from fastapi.responses import JSONResponse
from secrets import token_urlsafe


SECRET_KEY = "supersecretkey"  # Use a secure, random key in production
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

app = FastAPI()

models.Base.metadata.create_all(bind=engine)


app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Utility to verify and hash passwords
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

# Utility to create JWT token
def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def create_admin_user(db: Session):
    admin_username = "admin"
    existing_admin = crud.get_user_by_username(db, username=admin_username)
    if not existing_admin:
        # Generate a secure random password
        random_password = token_urlsafe(16)
        hashed_password = get_password_hash(random_password)
        
        # Create the admin user
        admin_user = crud.create_user(db, username=admin_username, password=hashed_password)
        private_message = "rtctf{flag_would_be_here}"        
        new_note = models.Note(text=private_message, public=False, user_id=admin_user.id)
        db.add(new_note)
        db.commit()

@app.on_event("startup")
def on_startup():
    db = next(get_db())
    try:
        create_admin_user(db)
    finally:
        db.close()

# Middleware to retrieve the current user from the session token
def get_current_user(request: Request, db: Session = Depends(get_db)):
    token = request.cookies.get("session_token")
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")

    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("user_id")
        if user_id is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
        user = db.query(models.User).filter(models.User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")
        return user
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")


# Home page showing the first 15 users with links to their public notes
@app.get("/", response_class=HTMLResponse)
async def home_page(request: Request, db: Session = Depends(get_db)):
    # Check if the session token is present in cookies
    user_is_logged_in = request.cookies.get("session_token") is not None
    users = db.query(models.User).limit(15).all()
    return templates.TemplateResponse("home.html", {
        "request": request,
        "users": users,
        "user_is_logged_in": user_is_logged_in
    })


# Register user form (GET) and handler (POST)
@app.get("/register", response_class=HTMLResponse)
async def register_form(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.post("/register")
async def register_user(username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    if crud.get_user_by_username(db, username=username):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username already registered")
    hashed_password = get_password_hash(password)
    crud.create_user(db, username=username, password=hashed_password)
    return RedirectResponse(url="/login", status_code=status.HTTP_303_SEE_OTHER)

# Login form (GET) and login handler (POST)
@app.get("/login", response_class=HTMLResponse)
async def login_form(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
async def login_user(response: Response, username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = crud.get_user_by_username(db, username=username)
    if not user or not verify_password(password, user.password):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid credentials")
    
    # Create access token
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(data={"user_id": user.id}, expires_delta=access_token_expires)
    
    # Set cookie on JSON response
    response = JSONResponse(content={"message": "Login successful"})
    response.set_cookie(key="session_token", value=access_token, httponly=True, max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60)
    
    # Redirect after setting the cookie
    response.headers["Location"] = "/my-notes"
    response.status_code = status.HTTP_303_SEE_OTHER
    return response


# My Notes page (GET) - Shows user's notes and form to create new notes
@app.get("/my-notes", response_class=HTMLResponse)
async def my_notes_page(request: Request, db: Session = Depends(get_db)):
    # Similarly, check if the user is logged in
    user_is_logged_in = request.cookies.get("session_token") is not None
    current_user = None
    try:
        current_user = get_current_user(request, db)
    except HTTPException:
        # User is not authenticated, handle accordingly
        pass
    notes = []
    username = ""
    if current_user:
        notes = db.query(models.Note).filter(models.Note.user_id == current_user.id).all()
        username = current_user.username

    return templates.TemplateResponse("my_notes.html", {
        "request": request,
        "notes": notes,
        "username": username,
        "user_is_logged_in": user_is_logged_in
    })

# Create new note (POST)
@app.post("/my-notes")
async def create_note(text: str = Form(...), public: bool = Form(False), db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    new_note = models.Note(text=text, public=public, user_id=current_user.id)
    db.add(new_note)
    db.commit()
    return RedirectResponse(url="/my-notes", status_code=303)

# Change password page (GET) and password change handler (POST) without user identity check
@app.get("/change-password", response_class=HTMLResponse)
async def change_password_form(request: Request):
    # Ensure the user is logged in before accessing the form
    user_is_logged_in = request.cookies.get("session_token") is not None
    if not user_is_logged_in:
        return RedirectResponse(url="/login", status_code=status.HTTP_303_SEE_OTHER)
    return templates.TemplateResponse("change_password.html", {"request": request})

@app.post("/change-password")
async def change_password(request: Request, username: str = Form(...), new_password: str = Form(...), db: Session = Depends(get_db)):
    try:
        # Get the current user from the session
        current_user = get_current_user(request, db)
    except HTTPException:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")

    if current_user:
        user = crud.get_user_by_username(db, username=username)
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    # Hash the new password and update the user record
        user.password = get_password_hash(new_password)
        db.commit()

        # Redirect to home page or a confirmation page
        return RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)
    else:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")
    


@app.get("/users/{username}", response_class=HTMLResponse)
async def public_notes_by_user(request: Request, username: str, db: Session = Depends(get_db)):
    user = crud.get_user_by_username(db, username=username)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    
    # Fetch only public notes
    public_notes = db.query(models.Note).filter(models.Note.user_id == user.id, models.Note.public == True).all()
    
    return templates.TemplateResponse("user_notes.html", {
        "request": request,
        "username": username,
        "public_notes": public_notes  # Make sure this matches the template's variable
    })

@app.post("/create-note")
async def create_note(text: str = Form(...), public: bool = Form(...), db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    crud.create_note(db, text=text, public=public, user_id=current_user.id)
    return RedirectResponse(url="/my-notes", status_code=status.HTTP_303_SEE_OTHER)


