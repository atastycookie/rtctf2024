import time
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

from flask import Flask, request, render_template
from pow_client import POWClient

ROUTER_URL = "http://openwrt-router:8080"
ROUTER_PASSWORD = os.getenv('OPENWRT_ROOT_PASSWORD')

CHROMEDRIVER_PATH = os.popen("echo /chromedriver/*/*/chromedriver").read().strip()

service = Service(executable_path=CHROMEDRIVER_PATH)
options = Options()
options.binary_location = os.popen("echo /chrome-headless-shell/*/*/chrome-headless-shell").read().strip()
options.headless = True
options.add_argument('--no-sandbox')

pow_client = POWClient()

def login_and_navigate(url_to_navigate):
    if not (url_to_navigate.startswith("http://") or url_to_navigate.startswith("https://")):
        return "Invalid URL"

    driver = webdriver.Chrome(service=service, options=options)
    try:
        driver.get(ROUTER_URL)

        password_field = WebDriverWait(driver, 2).until(
            EC.presence_of_element_located((By.NAME, "luci_password"))
        )

        password_field.send_keys(ROUTER_PASSWORD)

        login_button = driver.find_element(By.XPATH, "//input[@type='submit']")
        login_button.click()

        WebDriverWait(driver, 2).until(
            EC.presence_of_element_located((By.XPATH, "//*[@id='xhr_poll_status_on']"))
        )

        time.sleep(0.5)
        driver.get(url_to_navigate)
        time.sleep(2)

        return "Login successful and navigated to user URL!"
    except Exception as e:
        return f"An error occurred: {str(e)}"
    finally:
        driver.quit()



app = Flask(__name__)
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        pow_token = request.form['pow_token']

        is_valid, error_message = pow_client.validate_token(pow_token)
        if not is_valid:
            return render_template('result.html', result=f"PoW token validation failed: {error_message}")

        url_to_navigate = request.form['url']
        result = login_and_navigate(url_to_navigate)
        return render_template('result.html', result=result)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=9999)
