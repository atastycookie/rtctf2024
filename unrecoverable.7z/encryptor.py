import random
import sys

RNG_SEED = 0xdeadbeef
DENSITY_FACTOR = 8

def reseed_rng():
    random.seed(a=RNG_SEED, version=2)

def iteration(src):  # Transform(src) -> dest
    src_len = len(src)
    density = src_len * DENSITY_FACTOR
    dest = b''
    for _ in range(density):
        a, b = random.randint(0, src_len - 1), random.randint(0, src_len - 1)
        op_type = random.randint(0, 2)
        if op_type == 0:
            dest += bytes([(src[a] ^ src[b]) % 256])
        elif op_type == 1:
            dest += bytes([(src[a] + src[b]) % 256])
        elif op_type == 2:
            dest += bytes([(src[a] & src[b]) % 256])
        else:
            print('panic! (unknown op_type)')
            exit(1)
    return dest


def n_iters(flag, N):
    reseed_rng()
    for sym in flag:
        if sym >= 32 and sym <= 127:
            pass  # good
        else:
            print('panic! (ord(sym) >= 32 and ord(sym) <= 127 not true)')
            exit(1)
    dest = flag
    for _ in range(N):
        dest = iteration(dest)
    return dest


if len(sys.argv) < 2:
    print('panic! (no flag specified)')
    exit(1)

layers = 5
flag = sys.argv[1].encode('utf-8')
encrypted = n_iters(flag, layers)
print('Length of the flag:', len(flag))

with open('flag.enc', 'wb') as f:
    f.write(encrypted)
