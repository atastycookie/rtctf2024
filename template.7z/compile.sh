#!/bin/sh
emcc -o pi.js -s BINARYEN_ASYNC_COMPILATION=0 -s ENVIRONMENT=shell pi.cpp
