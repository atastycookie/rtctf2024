#!/bin/sh
pip install -r requirements.txt
python setup.py develop
