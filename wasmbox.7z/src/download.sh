#!/bin/bash

FILE_URL="https://github.com/golemfactory/sp-wasm/releases/download/0.1.0/sp-wasm-0.1.0.tar.gz"
EXPECTED_CHECKSUM="5f15d56d2ad353a7af8beb574847b2586591c3b4b3e9a4a6e001de12246ec823"
FILE_NAME="sp-wasm-0.1.0.tar.gz"

wget -O "$FILE_NAME" "$FILE_URL"

CALCULATED_CHECKSUM=$(sha256sum "$FILE_NAME" | awk '{ print $1 }')

if [ "$CALCULATED_CHECKSUM" == "$EXPECTED_CHECKSUM" ]; then
    echo "Checksum matches."
else
    echo "Checksum does not match."
    exit 1
fi
