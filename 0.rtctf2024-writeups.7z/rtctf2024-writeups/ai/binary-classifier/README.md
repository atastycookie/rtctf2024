## Название: Binary Classifier
**Описание**: Как-то раз я решал таск из категории stego, где было два вида картинок, которыми кодировались биты 0 и 1. Но что делать, если картинок не 10, не 100, а почти 10000?  
**Флаг**: `rtctf{n0t_t0O@_Many_1mAG3S_f0r_hard_working_AI_e5912872b641bf8c711bacdf8fa3fd3ecdc0a0c79b0ad4410b9f096e10fcbd64}`  
**Решение**:  
Я использовал CLIP через библиотеку `clip-cpp` (https://github.com/monatis/clip.cpp - GGML под капотом) и модель `clip-vit-base-patch32_ggml-model-q4_0.gguf` (https://huggingface.co/mys/ggml_clip-vit-base-patch32). Датасет при этом не пригодился (т.к. CLIP относится к "Zero-shot Image Classificatiors").  
Как и сказано в `README!!!.txt`, достаточно реализовать классификатор в файле `your_solution.py`:
```python
# pip install clip-cpp==0.5.0

import tempfile
import os
import pillow_jxl
from PIL import Image
from clip_cpp import Clip

repo_id = 'mys/ggml_clip-vit-base-patch32'
model_file = 'clip-vit-base-patch32_ggml-model-q4_0.gguf'

model = Clip(
    model_path_or_repo_id=repo_id,
    model_file=model_file,
    verbosity=2
)


text_embed_horse = model.encode_text(model.tokenize('a photo of a horse'))
text_embed_bull = model.encode_text(model.tokenize('a photo of a bull'))

def decide_image_type(image_path: str) -> bool:
    if horse_or_bull(image_path) == 'horse':
        return True
    return False

def horse_or_bull(img_path):
    image_2encode = Image.open(img_path)
    
    with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as temp_file:
        temp_filename = temp_file.name
        image_2encode.save(temp_filename, 'JPEG')

    image_embed = model.load_preprocess_encode_image(temp_filename)
    
    score_horse = model.calculate_similarity(text_embed_horse, image_embed)
    score_bull = model.calculate_similarity(text_embed_bull, image_embed)
    
    os.unlink(temp_filename)
    
    if score_horse > score_bull:
        return 'horse'
    else:
        return 'bull'
```

Запускаю:
```sh
$ python3 main.py try_to_solve
This codec can correct up to 100 errors and 200 erasures independently
maxerrors=100
[File Info] models/clip-vit-base-patch32_ggml-model-q4_0.gguf
clip_model_load: model name:   openai/clip-vit-base-patch32
clip_model_load: description:  two-tower CLIP model
clip_model_load: GGUF version: 2
clip_model_load: alignment:    32
clip_model_load: n_tensors:    397
clip_model_load: n_kv:         26
clip_model_load: ftype:        q4_0

clip_model_load: text_encoder:   1
clip_model_load: vision_encoder: 1
clip_model_load: model size:     85.18 MB
clip_model_load: metadata size:  0.13 MB

clip_model_load: text model hparams
n_vocab            49408
num_positions      77
t_hidden_size      512
t_n_intermediate   2048
t_projection_dim   512
t_n_head           8
t_n_layer          12

clip_model_load: vision model hparams
image_size         224
patch_size         32
v_hidden_size      768
v_n_intermediate   3072
v_projection_dim   512
v_n_head           12
v_n_layer          12

clip_model_load: 24 MB of memory allocated
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
.......
1209
1210
1211
1212
1213
1214
1215
1216
1217
1218
1219
1220
1221
1222
1223
1224
1225
1226
1227
1228
Data len: 1228
b'rtctf{n0t_t0O@_Many_1mAG3S_f0r_hard_working_AI_e5912872b641bf8c711bacdf8fa3fd3ecdc0a0c79b0ad4410b9f096e10fcbd64}'
Congratz! You did it!
```
