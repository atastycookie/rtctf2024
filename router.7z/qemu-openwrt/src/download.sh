#!/bin/bash

FILE_URL="https://archive.openwrt.org/releases/18.06.0/targets/x86/64/openwrt-18.06.0-x86-64-combined-ext4.img.gz"
EXPECTED_CHECKSUM="21ba3e27de02fb063d2d9d5512682f3ea382774496d37d92d2931e8d25f7ba21"
FILE_NAME="openwrt-18.06.0-x86-64-combined-ext4.img.gz"

wget -O "$FILE_NAME" "$FILE_URL"

CALCULATED_CHECKSUM=$(sha256sum "$FILE_NAME" | awk '{ print $1 }')

if [ "$CALCULATED_CHECKSUM" == "$EXPECTED_CHECKSUM" ]; then
    echo "Checksum matches."
else
    echo "Checksum does not match."
    exit 1
fi
