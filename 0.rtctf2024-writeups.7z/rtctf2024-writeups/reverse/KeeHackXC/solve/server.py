from flask import Flask, request
import binascii

app = Flask(__name__)

@app.route('/', methods=['POST'])
def receive_data():
    # Force the content type to be treated as application/octet-stream
    if request.content_type != 'application/octet-stream':
        request.environ['CONTENT_TYPE'] = 'application/octet-stream'
    
    encrypted_data = request.get_data()

    hex_string = binascii.hexlify(encrypted_data).decode('utf-8')

    print("Received encrypted data (hex):")
    print(hex_string)

    return "ok", 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=False)
